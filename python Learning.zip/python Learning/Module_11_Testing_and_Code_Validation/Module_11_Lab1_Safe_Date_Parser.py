"""
Module 11 - Lab 1: Safe Date Parser
====================================

PROBLEM
-------
Write a function that converts string representations of dates into
datetime objects. Use a try/except block to catch ValueError if the
date format is incorrect, returning a safe default instead of crashing.

This lab demonstrates defensive input validation: instead of letting a
malformed date string crash the whole program with an unhandled
ValueError, the parser tries several plausible formats and, if none of
them match, logs a warning and falls back to a safe default value
(a "fail-safe" strategy, as opposed to "fail-fast").

Supported input formats (at least 2, as required):
    - "YYYY-MM-DD"   e.g. "2025-03-14"   (ISO 8601, most common in APIs/DBs)
    - "DD/MM/YYYY"   e.g. "14/03/2025"   (common in many non-US locales)
    - "MM/DD/YYYY"   e.g. "03/14/2025"   (common in US-style input forms)
"""

from datetime import datetime
import logging

# A basic logger so the "warning on fallback" requirement produces a
# clearly visible message even if the host application has no logging
# configuration of its own.
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger("safe_date_parser")

# The formats we are willing to try, in order. Using strptime's format
# codes keeps this explicit and easy to extend later.
_SUPPORTED_FORMATS = [
    "%Y-%m-%d",   # 2025-03-14
    "%d/%m/%Y",   # 14/03/2025
    "%m/%d/%Y",   # 03/14/2025
]

# A deliberately obvious, easy-to-spot sentinel default. Using None is
# also common, but an explicit "epoch-like" sentinel date makes it easy
# to notice a parsing failure downstream if the warning log is missed.
DEFAULT_DATE = datetime(1970, 1, 1)


def parse_date_safe(raw_value, default=DEFAULT_DATE, formats=None):
    """
    Convert a string representation of a date into a datetime object.

    Tries each format in `formats` (defaulting to _SUPPORTED_FORMATS) in
    order. The first format that parses successfully wins. If none of
    the formats match -- or the input isn't a string at all -- a
    warning is logged and `default` is returned instead of letting the
    ValueError (or TypeError) propagate and crash the caller.

    Parameters
    ----------
    raw_value : str
        The date string to parse, e.g. "2025-03-14".
    default : datetime
        The safe value to return if parsing fails. Defaults to
        DEFAULT_DATE (1970-01-01).
    formats : list[str] | None
        Optional override of the strptime format strings to attempt.

    Returns
    -------
    datetime
        The parsed date, or `default` if parsing was not possible.
    """
    formats = formats if formats is not None else _SUPPORTED_FORMATS

    # Guard clause: non-string input can never be parsed by strptime and
    # would raise a TypeError rather than a ValueError, so we validate
    # the type up front before entering the try/except for the format
    # attempts themselves.
    if not isinstance(raw_value, str) or not raw_value.strip():
        logger.warning(
            "parse_date_safe: input %r is not a usable date string -- "
            "falling back to default %s",
            raw_value,
            default.date(),
        )
        return default

    cleaned = raw_value.strip()

    for fmt in formats:
        try:
            # The happy path: strptime succeeds and we return immediately.
            return datetime.strptime(cleaned, fmt)
        except ValueError:
            # This specific format didn't match this string -- that's
            # expected and not an error condition yet, so we simply try
            # the next candidate format instead of giving up.
            continue

    # If we fall through the loop, none of the supported formats matched.
    # Rather than letting a ValueError crash the caller, we log a clear
    # warning (so the bad data is visible/auditable) and return the safe
    # default, letting the rest of the program keep running.
    logger.warning(
        "parse_date_safe: could not parse date string '%s' using any of "
        "%s -- falling back to default %s",
        cleaned,
        formats,
        default.date(),
    )
    return default


if __name__ == "__main__":
    print("=" * 70)
    print("Module 11 - Lab 1: Safe Date Parser - Demo")
    print("=" * 70)

    demo_inputs = [
        "2025-03-14",     # happy path: ISO format
        "14/03/2025",     # happy path: DD/MM/YYYY format
        "03/14/2025",     # happy path: MM/DD/YYYY format
        "14th of March",  # invalid path -> safe default + warning
        "2025-13-40",     # invalid path: out-of-range month/day -> safe default
        "",               # invalid path: empty string -> safe default
        None,             # invalid path: wrong type entirely -> safe default
    ]

    print("\n--- Happy path & invalid path demonstration ---\n")
    for value in demo_inputs:
        result = parse_date_safe(value)
        status = "OK" if result is not DEFAULT_DATE else "FALLBACK"
        print(f"input={value!r:<18} -> {result.date()}  [{status}]")

    print("\n--- Custom default value ---\n")
    custom_default = datetime(2000, 1, 1)
    result = parse_date_safe("not-a-date", default=custom_default)
    print(f"input='not-a-date' with custom default -> {result.date()}")

    print("\nDemo complete: happy-path strings parsed correctly, and every")
    print("invalid input safely fell back to a default instead of crashing.")
