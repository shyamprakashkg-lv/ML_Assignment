"""
Module 11 - Lab 2: Unit Testing Practice with unittest
=======================================================

PROBLEM
-------
Implement a small business function, `calculate_discounted_price`, that
applies a percentage discount to a price while rejecting clearly invalid
input (a negative price, or a discount percentage outside 0-100). Then
write a unittest.TestCase covering normal cases, boundary cases, and
invalid-input cases (via assertRaises).

Running this file directly executes the full test suite with
unittest.main() and all tests must pass.
"""

import unittest


# ---------------------------------------------------------------------
# Reference solution: the function under test
# ---------------------------------------------------------------------
def calculate_discounted_price(price, discount_pct):
    """
    Return the price after applying a percentage discount, rounded to
    2 decimal places (as money normally is).

    Parameters
    ----------
    price : float | int
        The original price. Must be >= 0.
    discount_pct : float | int
        The discount to apply, expressed as a percentage (0-100).

    Returns
    -------
    float
        The discounted price, rounded to 2 decimal places.

    Raises
    ------
    ValueError
        If `price` is negative, or `discount_pct` is outside 0-100.
    """
    # Defensive validation: reject impossible business inputs immediately
    # ("fail fast") rather than silently producing a nonsensical result
    # such as a negative price or a price above the original.
    if price < 0:
        raise ValueError(f"price cannot be negative, got {price}")
    if not (0 <= discount_pct <= 100):
        raise ValueError(
            f"discount_pct must be between 0 and 100, got {discount_pct}"
        )

    # Core calculation: discount_pct=0 -> full price, discount_pct=100 -> 0.
    discounted = price * (1 - discount_pct / 100)

    # Round to 2 decimal places since this represents currency.
    return round(discounted, 2)


# ---------------------------------------------------------------------
# Test suite
# ---------------------------------------------------------------------
class TestCalculateDiscountedPrice(unittest.TestCase):
    """Covers normal cases, boundary cases, and invalid-input cases."""

    def setUp(self):
        # Shared fixture recreated before every single test method, so
        # no test can accidentally leak state into another.
        self.full_price = 200.0

    # ---- Normal cases -------------------------------------------------
    def test_no_discount_returns_full_price(self):
        """0% discount should return the price unchanged."""
        self.assertEqual(calculate_discounted_price(self.full_price, 0), 200.0)

    def test_fifty_percent_discount(self):
        """50% discount should halve the price."""
        self.assertEqual(calculate_discounted_price(self.full_price, 50), 100.0)

    def test_twenty_five_percent_discount_rounds_correctly(self):
        """A discount that produces a fractional cent should round to 2dp."""
        # 99.99 * (1 - 0.25) = 74.9925 -> rounds to 74.99 (banker's/half-even
        # rounding in Python's round(); verified explicitly below).
        result = calculate_discounted_price(99.99, 25)
        self.assertAlmostEqual(result, 74.99, places=2)

    # ---- Boundary cases -------------------------------------------------
    def test_hundred_percent_discount_returns_zero(self):
        """100% discount is the upper boundary and should return 0.0."""
        self.assertEqual(calculate_discounted_price(self.full_price, 100), 0.0)

    def test_zero_price_with_any_discount_returns_zero(self):
        """A price of exactly 0 (lower boundary) should always return 0."""
        self.assertEqual(calculate_discounted_price(0, 50), 0.0)

    def test_discount_boundary_values_are_accepted(self):
        """discount_pct of exactly 0 and exactly 100 are valid, not errors."""
        # Both ends of the valid range must be accepted without raising.
        self.assertEqual(calculate_discounted_price(50.0, 0), 50.0)
        self.assertEqual(calculate_discounted_price(50.0, 100), 0.0)

    # ---- Invalid-input cases (assertRaises) ----------------------------
    def test_negative_price_raises_value_error(self):
        """A negative price makes no business sense and must raise."""
        with self.assertRaises(ValueError):
            calculate_discounted_price(-10, 10)

    def test_discount_above_100_raises_value_error(self):
        """A discount greater than 100% makes no business sense."""
        with self.assertRaises(ValueError):
            calculate_discounted_price(self.full_price, 150)

    def test_negative_discount_raises_value_error(self):
        """A negative discount (i.e. a surcharge) is out of scope here."""
        with self.assertRaises(ValueError):
            calculate_discounted_price(self.full_price, -5)


if __name__ == "__main__":
    print("=" * 70)
    print("Module 11 - Lab 2: Unit Testing Practice - Running test suite")
    print("=" * 70)
    unittest.main(verbosity=2)
