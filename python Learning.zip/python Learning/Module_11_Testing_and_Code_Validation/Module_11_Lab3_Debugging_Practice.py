"""
Module 11 - Lab 3: Debugging Practice
======================================

PROBLEM
-------
This lab demonstrates how a trainer would find and fix a realistic,
seeded bug. It contains:

  1. A "BUGGY VERSION" of a function, kept only as a docstring/comment
     below (never executed), with a deliberate off-by-one error.
  2. The corrected, working version that actually runs.
  3. A walkthrough of how the bug would be found using print-debugging
     and pdb/breakpoint(), written as comments.

The scenario: a function that computes the "moving average" of the last
N days of sales figures, used to smooth out daily noise for a reporting
dashboard.

-----------------------------------------------------------------------
BUGGY VERSION (DO NOT RUN -- kept for reference / training discussion
only, deliberately left unexecuted):

    def moving_average(sales, window):
        '''Average of the last `window` entries in `sales`.'''
        # BUG: off-by-one in the slice start index. sales[-window + 1:]
        # drops the oldest day that should be included in the window,
        # so a "window=3" average is silently computed over only 2 days.
        recent = sales[-window + 1:]
        return sum(recent) / window      # BUG #2: dividing by `window`
                                          # (3) even though `recent` only
                                          # has `window - 1` (2) entries,
                                          # so the result is also scaled
                                          # wrong on top of using the
                                          # wrong days.

    # Symptom as it would appear in production:
    #   moving_average([10, 20, 30], 3)
    #   Buggy result:    16.67   (wrong: sums only [20, 30] = 50, then
    #                             divides by 3 instead of 2)
    #   Expected result: 20.0    (true average of [10, 20, 30])
-----------------------------------------------------------------------

HOW THE BUG WOULD BE FOUND (trainer walkthrough, as comments):

  Step 1 - print-debugging:
    A developer notices the dashboard's 3-day average looks too low and
    adds a quick print() right before the return statement:
        print(f"window={window} recent={recent} sum={sum(recent)}")
    Running moving_average([10, 20, 30], 3) prints:
        window=3 recent=[20, 30] sum=50
    That immediately shows two things are wrong: `recent` has only 2
    elements instead of 3, and the first day (10) is missing entirely.

  Step 2 - pdb / breakpoint():
    To confirm *why* the slice is wrong without editing the file again,
    the developer runs the buggy function under the debugger:
        breakpoint()                  # placed just above `recent = ...`
    At the (Pdb) prompt they step through:
        (Pdb) p window                -> 3
        (Pdb) p -window + 1           -> -2       <- the slice start!
        (Pdb) p sales[-2:]            -> [20, 30] <- confirms only 2 items
        (Pdb) n                       -> steps to the `return` line
        (Pdb) p recent                -> [20, 30]
        (Pdb) c                       -> lets execution continue/finish
    Seeing `-window + 1` evaluate to -2 (instead of the intended -3)
    makes the off-by-one immediately obvious: the fix is `-window`, not
    `-window + 1`.

  Step 3 - fix and verify:
    Correct the slice to `sales[-window:]` so it includes exactly
    `window` entries, counting from the correct day, and re-run the
    happy-path case to confirm the average now matches the expected
    value by hand (10 + 20 + 30) / 3 = 20.0.
-----------------------------------------------------------------------
"""


# ---------------------------------------------------------------------
# CORRECTED VERSION (this is the only version actually executed)
# ---------------------------------------------------------------------
def moving_average(sales, window):
    """
    Return the average of the last `window` entries in `sales`.

    Parameters
    ----------
    sales : list[float]
        A chronological list of daily sales figures (oldest first).
    window : int
        How many of the most recent entries to average over. Must be
        a positive integer no larger than len(sales).

    Returns
    -------
    float
        The average of the last `window` entries.

    Raises
    ------
    ValueError
        If `window` is not a positive integer, or exceeds the number
        of available data points.
    """
    # Defensive validation first, so a bad `window` value fails loudly
    # and clearly rather than silently producing a misleading average.
    if window <= 0:
        raise ValueError(f"window must be positive, got {window}")
    if window > len(sales):
        raise ValueError(
            f"window ({window}) cannot exceed the number of data points "
            f"({len(sales)})"
        )

    # FIX: slicing with -window (not "-window + 1") correctly selects
    # exactly the last `window` entries, e.g. for window=3 this takes
    # sales[-3:] -- the last 3 days, inclusive of the oldest one in the
    # window. This is the corrected counterpart of the seeded off-by-
    # one bug documented above.
    recent = sales[-window:]

    # `recent` now always has exactly `window` elements, so dividing by
    # `window` here is correct and consistent with what was summed.
    return sum(recent) / window


if __name__ == "__main__":
    print("=" * 70)
    print("Module 11 - Lab 3: Debugging Practice - Corrected Version Demo")
    print("=" * 70)

    daily_sales = [10, 20, 30, 40, 50, 60, 70]

    print(f"\nDaily sales data: {daily_sales}\n")

    for window in (1, 2, 3, 7):
        avg = moving_average(daily_sales, window)
        last_n = daily_sales[-window:]
        print(f"window={window} -> last {window} day(s) {last_n} "
              f"-> moving average = {avg:.2f}")

    print("\n--- Hand-verified example from the bug report ---")
    result = moving_average([10, 20, 30], 3)
    expected = (10 + 20 + 30) / 3
    print(f"moving_average([10, 20, 30], 3) = {result:.2f} "
          f"(expected {expected:.2f})")
    assert result == expected, "regression: corrected version should match hand calc"

    print("\n--- Invalid input still fails fast, as designed ---")
    try:
        moving_average(daily_sales, 0)
    except ValueError as exc:
        print(f"window=0 correctly raised ValueError: {exc}")

    try:
        moving_average(daily_sales, 100)
    except ValueError as exc:
        print(f"window=100 correctly raised ValueError: {exc}")

    print("\nDemo complete: the corrected version produces the expected "
          "averages and the seeded off-by-one bug no longer reproduces.")
