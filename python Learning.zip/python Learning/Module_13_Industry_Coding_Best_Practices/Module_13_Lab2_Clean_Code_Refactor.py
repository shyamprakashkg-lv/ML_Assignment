"""
Module_13_Lab2_Clean_Code_Refactor.py
--------------------------------------
Lab: Clean Code Refactor.

This file contains TWO implementations of the same business logic --
calculating the final cost of a shipping order, including weight-based
charges, a distance surcharge, a bulk-order discount, and an express
delivery fee.

  * BEFORE : a deliberately messy version (poor names, magic numbers,
    deep nesting, no docstring/type hints, several unrelated
    responsibilities crammed into one function).

  * AFTER  : a refactored version following every clean-code principle
    covered in Module 13 -- meaningful names, docstrings, type hints,
    named constants, small single-purpose helper functions, and early
    returns instead of deep nesting.

Both versions are proven to produce IDENTICAL output for the same
inputs in the `if __name__ == "__main__":` block below.
"""

from typing import Union

Number = Union[int, float]


# ======================================================================
# BEFORE: messy, unmaintainable version
# ======================================================================
def calc(o):
    # o is expected to be a dict with keys: "w" (weight kg), "d" (distance km),
    # "q" (quantity of packages), "x" (express flag)
    if o is not None:
        if o["w"] > 0:
            if o["d"] > 0:
                if o["q"] > 0:
                    tmp2 = o["w"] * 2.5
                    tmp2 = tmp2 + o["d"] * 0.15
                    tmp2 = tmp2 * o["q"]
                    if o["q"] >= 10:
                        if o["q"] >= 50:
                            tmp2 = tmp2 * 0.8
                        else:
                            tmp2 = tmp2 * 0.9
                    if o["x"] == True:
                        tmp2 = tmp2 + 12.5
                        if tmp2 < 20:
                            tmp2 = 20
                    else:
                        if tmp2 < 5:
                            tmp2 = 5
                    return round(tmp2, 2)
                else:
                    return 0
            else:
                return 0
        else:
            return 0
    else:
        return 0


# ======================================================================
# AFTER: clean, maintainable refactor of the SAME logic
# ======================================================================

# --- Named constants (no magic numbers) --------------------------------
COST_PER_KG = 2.5
COST_PER_KM = 0.15

BULK_DISCOUNT_THRESHOLD_MEDIUM = 10   # 10+ packages
BULK_DISCOUNT_RATE_MEDIUM = 0.9       # 10% off

BULK_DISCOUNT_THRESHOLD_LARGE = 50    # 50+ packages
BULK_DISCOUNT_RATE_LARGE = 0.8        # 20% off

EXPRESS_SURCHARGE = 12.5
MINIMUM_STANDARD_COST = 5.0
MINIMUM_EXPRESS_COST = 20.0


def calculate_shipping_cost(order: dict) -> float:
    """Calculate the total shipping cost for an order.

    The cost is based on package weight and shipping distance, scaled by
    quantity, with a bulk-order discount for larger shipments and an
    optional express-delivery surcharge. A minimum cost floor applies so
    that very small or very cheap orders are never undercharged.

    Args:
        order: A dict describing the shipment, with keys:
            "weight_kg" (float): weight of a single package, in kg.
            "distance_km" (float): shipping distance, in km.
            "quantity" (int): number of packages in the order.
            "express" (bool): whether express delivery is requested.

    Returns:
        The total shipping cost in USD, rounded to 2 decimal places.
        Returns 0.0 if the order is missing or has non-positive
        weight, distance, or quantity (i.e. there is nothing to ship).

    Examples:
        >>> calculate_shipping_cost(
        ...     {"weight_kg": 2, "distance_km": 10, "quantity": 1, "express": False}
        ... )
        6.5
    """
    if not _is_shippable(order):
        return 0.0

    base_cost = _calculate_base_cost(order)
    discounted_cost = _apply_bulk_discount(base_cost, order["quantity"])
    final_cost = _apply_express_surcharge_and_minimum(
        discounted_cost, order["express"]
    )
    return round(final_cost, 2)


def _is_shippable(order: dict) -> bool:
    """An order can be shipped only if it exists and has positive values."""
    if order is None:
        return False
    return (
        order["weight_kg"] > 0
        and order["distance_km"] > 0
        and order["quantity"] > 0
    )


def _calculate_base_cost(order: dict) -> float:
    """Compute the pre-discount cost from weight, distance, and quantity."""
    per_package_cost = (
        order["weight_kg"] * COST_PER_KG + order["distance_km"] * COST_PER_KM
    )
    return per_package_cost * order["quantity"]


def _apply_bulk_discount(cost: float, quantity: int) -> float:
    """Apply a volume discount for medium or large bulk orders."""
    if quantity >= BULK_DISCOUNT_THRESHOLD_LARGE:
        return cost * BULK_DISCOUNT_RATE_LARGE
    if quantity >= BULK_DISCOUNT_THRESHOLD_MEDIUM:
        return cost * BULK_DISCOUNT_RATE_MEDIUM
    return cost


def _apply_express_surcharge_and_minimum(cost: float, express: bool) -> float:
    """Add the express surcharge (if requested) and enforce a cost floor."""
    if express:
        cost += EXPRESS_SURCHARGE
        return max(cost, MINIMUM_EXPRESS_COST)
    return max(cost, MINIMUM_STANDARD_COST)


# ======================================================================
# Proof: BEFORE and AFTER produce identical output on the same inputs
# ======================================================================
if __name__ == "__main__":
    test_orders = [
        {"w": 2, "d": 10, "q": 1, "x": False},
        {"w": 5, "d": 100, "q": 1, "x": True},
        {"w": 1, "d": 5, "q": 10, "x": False},
        {"w": 3, "d": 50, "q": 50, "x": True},
        {"w": 0.5, "d": 2, "q": 1, "x": False},
        {"w": 10, "d": 200, "q": 75, "x": False},
        {"w": -1, "d": 10, "q": 1, "x": False},   # invalid: negative weight
        {"w": 2, "d": 0, "q": 1, "x": False},     # invalid: zero distance
        {"w": 2, "d": 10, "q": 0, "x": True},     # invalid: zero quantity
        None,                                      # invalid: no order at all
    ]

    print("=" * 70)
    print("Comparing BEFORE (calc) vs AFTER (calculate_shipping_cost)")
    print("=" * 70)

    all_match = True
    for i, order in enumerate(test_orders, 1):
        before_result = calc(order)

        if order is None:
            after_result = calculate_shipping_cost(order)
        else:
            after_result = calculate_shipping_cost(
                {
                    "weight_kg": order["w"],
                    "distance_km": order["d"],
                    "quantity": order["q"],
                    "express": order["x"],
                }
            )

        match = before_result == after_result
        all_match = all_match and match
        status = "OK " if match else "MISMATCH"
        print(
            f"[{status}] Test {i}: order={order} "
            f"-> before={before_result}, after={after_result}"
        )
        assert match, f"Mismatch on test {i}: {before_result} != {after_result}"

    print("-" * 70)
    if all_match:
        print("CONFIRMED: BEFORE and AFTER produce identical results on all "
              f"{len(test_orders)} test cases.")
    else:
        print("FAILURE: Some results did not match.")
