"""
cleaning.py
-----------
Core text-cleaning utilities for the data_cleaner package.

This module contains a single, focused, reusable function for stripping
special characters out of free-form text (e.g. messy CSV exports, survey
responses, or support-ticket subjects) while optionally preserving a set
of characters the caller wants to keep.
"""

import re


def remove_special_characters(text: str, keep: str = " ") -> str:
    """Remove special characters from a string.

    Any character that is not a letter (A-Z, a-z), a digit (0-9), or one
    of the characters listed in ``keep`` is stripped out. By default, a
    single space is kept so that word boundaries in normal sentences are
    preserved.

    Args:
        text: The raw input string to clean. May contain punctuation,
            symbols, emoji, or other non-alphanumeric characters.
        keep: A string of extra characters that should NOT be removed,
            in addition to letters and digits. Defaults to " " (space).
            Pass "" to strip everything down to only letters and digits.

    Returns:
        A new string containing only alphanumeric characters and any
        characters listed in ``keep``. The original string is never
        mutated (Python strings are immutable, but this is explicit by
        design: the function always returns a new value).

    Raises:
        TypeError: If ``text`` is not a string.

    Examples:
        >>> remove_special_characters("Hello, World! #2024")
        'Hello World 2024'
        >>> remove_special_characters("price: $19.99", keep=".@ ")
        'price 19.99'
        >>> remove_special_characters("")
        ''
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be a str, got {type(text).__name__}")

    # Edge case: empty string -> nothing to clean, return it as-is.
    if text == "":
        return text

    # Build a character class that keeps letters, digits, and anything
    # explicitly requested via `keep`. re.escape() protects against
    # `keep` containing regex-special characters (e.g. "." or "-").
    pattern = f"[^A-Za-z0-9{re.escape(keep)}]"
    cleaned = re.sub(pattern, "", text)

    # Edge case: collapse any run of multiple spaces left behind by
    # removed characters (e.g. "a,  b" -> "a b", not "a  b").
    if " " in keep or keep == " ":
        cleaned = re.sub(r" {2,}", " ", cleaned).strip()

    return cleaned
