"""
data_cleaner
------------
A small, reusable package providing text-cleaning utilities for messy,
real-world string data (CSV exports, survey text, support tickets, etc.).

Public API:
    remove_special_characters(text, keep=" ") -> str

Example:
    >>> from data_cleaner import remove_special_characters
    >>> remove_special_characters("Hello, World! #2024")
    'Hello World 2024'
"""

from .cleaning import remove_special_characters

__all__ = ["remove_special_characters"]
__version__ = "1.0.0"
