"""
main.py
-------
Demonstrates importing and using the custom `data_cleaner` package.

This script is deliberately kept separate from the package itself: it is
a *consumer* of data_cleaner, not part of it. That separation is exactly
what makes data_cleaner reusable -- any other script, service, or team
could import it the same way, without ever touching this file.

Run from inside this folder with:
    python3 main.py
"""

from data_cleaner import remove_special_characters

# A handful of realistic, messy strings you might see in production data.
SAMPLE_STRINGS = [
    "Hello, World! #2024",
    "Customer email: jane.doe@example.com !!!",
    "Order #A-123 -- total: $45.99 (USD)",
    "   Weird\tspacing...and\n\nnewlines???   ",
]


def main() -> None:
    """Clean each sample string and print a before/after comparison."""
    print("=" * 60)
    print("data_cleaner demo: remove_special_characters()")
    print("=" * 60)

    for raw in SAMPLE_STRINGS:
        cleaned = remove_special_characters(raw)
        print(f"BEFORE : {raw!r}")
        print(f"AFTER  : {cleaned!r}")
        print("-" * 60)

    # Demonstrate the `keep` parameter: preserve "." and "@" for an email.
    email_raw = "Contact: jane.doe@example.com!!"
    email_cleaned = remove_special_characters(email_raw, keep=".@ ")
    print(f"BEFORE (keep='.@ '): {email_raw!r}")
    print(f"AFTER  (keep='.@ '): {email_cleaned!r}")


if __name__ == "__main__":
    main()
