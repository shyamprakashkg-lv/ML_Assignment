"""
Module 12 - Lab 2: Algorithms Practice
========================================

Implements and demonstrates three core algorithmic ideas from the
module:

    (a) Linear search   - scan every element until a match is found.
    (b) Binary search   - repeatedly halve a SORTED list to find a target.
    (c) Recursion       - a classic recursive function (factorial), with
                          a short explanation of how the call stack grows
                          and unwinds.

The demo block at the bottom runs all three against sample data and
prints a direct comparison of how many comparisons linear vs. binary
search needed to find the SAME target in the SAME sorted dataset -
making the O(n) vs. O(log n) difference concrete rather than abstract.
"""

from typing import List, Tuple


# --------------------------------------------------------------------------
# (a) Linear search
# --------------------------------------------------------------------------
def linear_search(data: List[int], target: int) -> Tuple[int, int]:
    """Scan left to right until `target` is found.

    Returns (index_found_or_-1, comparisons_made).
    Works on data in ANY order - no assumptions about sorting.
    Worst case: O(n) comparisons.
    """
    comparisons = 0
    for index, value in enumerate(data):
        comparisons += 1
        if value == target:
            return index, comparisons
    return -1, comparisons


# --------------------------------------------------------------------------
# (b) Binary search
# --------------------------------------------------------------------------
def binary_search(sorted_data: List[int], target: int) -> Tuple[int, int]:
    """Repeatedly halve the search range until `target` is found.

    Requires `sorted_data` to already be sorted in ascending order.
    Returns (index_found_or_-1, comparisons_made).
    Worst case: O(log n) comparisons.
    """
    comparisons = 0
    low, high = 0, len(sorted_data) - 1
    while low <= high:
        comparisons += 1
        mid = (low + high) // 2
        if sorted_data[mid] == target:
            return mid, comparisons
        elif sorted_data[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1, comparisons


# --------------------------------------------------------------------------
# (c) Recursion - factorial, with call-stack commentary
# --------------------------------------------------------------------------
def factorial(n: int) -> int:
    """Return n! (n factorial) using recursion.

    Call-stack behaviour for factorial(4):
        factorial(4)                       # waits for factorial(3)
          -> factorial(3)                  # waits for factorial(2)
               -> factorial(2)             # waits for factorial(1)
                    -> factorial(1)        # base case: returns 1 immediately
                    <- returns 1
               <- returns 2 * 1  = 2
          <- returns 3 * 2  = 6
        <- returns 4 * 6  = 24

    Each nested call is pushed onto the call stack and stays there,
    waiting, until the call below it returns a value. The base case
    (n == 0 or n == 1) is what stops new frames from being pushed; without
    it, Python would eventually raise a RecursionError.
    """
    if n == 0 or n == 1:        # base case
        return 1
    return n * factorial(n - 1)  # recursive case: shrinks n toward the base case


def factorial_traced(n: int, depth: int = 0) -> int:
    """Same as factorial(), but prints each call/return to visualize the stack."""
    indent = "  " * depth
    print(f"{indent}-> factorial({n}) called")
    if n == 0 or n == 1:
        print(f"{indent}<- factorial({n}) returns 1 (base case)")
        return 1
    result = n * factorial_traced(n - 1, depth + 1)
    print(f"{indent}<- factorial({n}) returns {result}")
    return result


if __name__ == "__main__":
    # ---------------------------------------------------------------- (a)/(b)
    print("=== Linear Search vs. Binary Search ===")
    # Realistic scenario: a sorted list of customer account numbers.
    sorted_accounts = list(range(1000, 1000 + 20_000, 2))  # 20,000 sorted ids: 1000, 1002, ...
    search_target = sorted_accounts[-5]  # a value near the end -> worst case for linear search

    lin_index, lin_comparisons = linear_search(sorted_accounts, search_target)
    bin_index, bin_comparisons = binary_search(sorted_accounts, search_target)

    print(f"Dataset size: {len(sorted_accounts)} sorted account numbers")
    print(f"Target account number: {search_target}")
    print(f"Linear search  -> found at index {lin_index} in {lin_comparisons} comparisons")
    print(f"Binary search  -> found at index {bin_index} in {bin_comparisons} comparisons")
    print(f"Binary search needed {lin_comparisons - bin_comparisons} fewer comparisons "
          f"({lin_comparisons / bin_comparisons:.1f}x fewer) for this target.\n")

    # Sanity-check correctness on a small, easy-to-verify list too.
    small = [4, 8, 15, 16, 23, 42]
    assert linear_search(small, 23) == (4, 5)
    assert binary_search(small, 23)[0] == 4
    assert linear_search(small, 999) == (-1, len(small))
    assert binary_search(small, 999)[0] == -1
    print("Correctness checks on small list passed: both searches agree on "
          "found/not-found positions.\n")

    # ---------------------------------------------------------------- (c)
    print("=== Recursion: Factorial ===")
    for n in [0, 1, 5, 7]:
        print(f"factorial({n}) = {factorial(n)}")

    print("\n--- Traced call stack for factorial(4) ---")
    final_value = factorial_traced(4)
    print(f"\nFinal result: factorial(4) = {final_value}")
    assert final_value == 24
