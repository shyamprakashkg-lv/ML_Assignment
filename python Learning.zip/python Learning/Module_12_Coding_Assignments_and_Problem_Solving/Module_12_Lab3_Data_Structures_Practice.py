"""
Module 12 - Lab 3: Data Structures Practice
==============================================

Given a sample list of realistic customer-order records, this script
demonstrates:

    1. Deduplication using a `set` (unique customer IDs across all orders).
    2. Frequency counting using `collections.Counter` (orders per region).
    3. Grouping by a key into a `dict` of lists (orders grouped by region).
    4. A concrete timing comparison of `list` vs. `set` membership testing
       ("is this ID in my dataset?") over a synthetic 20,000-item dataset,
       using `time.perf_counter()` to make the O(n) vs. O(1) difference
       tangible rather than theoretical.
"""

import time
from collections import Counter
from typing import Dict, List


# --------------------------------------------------------------------------
# Sample data: realistic customer order records
# --------------------------------------------------------------------------
ORDERS = [
    {"order_id": "O-1001", "customer_id": "C-01", "region": "North", "amount": 129.50},
    {"order_id": "O-1002", "customer_id": "C-02", "region": "South", "amount": 59.99},
    {"order_id": "O-1003", "customer_id": "C-01", "region": "North", "amount": 75.00},
    {"order_id": "O-1004", "customer_id": "C-03", "region": "East", "amount": 220.00},
    {"order_id": "O-1005", "customer_id": "C-04", "region": "West", "amount": 15.25},
    {"order_id": "O-1006", "customer_id": "C-02", "region": "South", "amount": 42.10},
    {"order_id": "O-1007", "customer_id": "C-05", "region": "North", "amount": 310.75},
    {"order_id": "O-1008", "customer_id": "C-03", "region": "East", "amount": 18.00},
    {"order_id": "O-1009", "customer_id": "C-06", "region": "South", "amount": 99.99},
    {"order_id": "O-1010", "customer_id": "C-01", "region": "North", "amount": 64.40},
    {"order_id": "O-1011", "customer_id": "C-07", "region": "West", "amount": 150.00},
    {"order_id": "O-1012", "customer_id": "C-04", "region": "West", "amount": 27.80},
]


# --------------------------------------------------------------------------
# 1. Deduplication using a set
# --------------------------------------------------------------------------
def unique_customer_ids(orders: List[dict]) -> set:
    """Return the set of distinct customer IDs that placed at least one order."""
    return {order["customer_id"] for order in orders}


# --------------------------------------------------------------------------
# 2. Frequency counting using collections.Counter
# --------------------------------------------------------------------------
def orders_per_region(orders: List[dict]) -> Counter:
    """Return a Counter of how many orders were placed from each region."""
    return Counter(order["region"] for order in orders)


# --------------------------------------------------------------------------
# 3. Grouping by a key into a dict of lists
# --------------------------------------------------------------------------
def group_orders_by_region(orders: List[dict]) -> Dict[str, List[dict]]:
    """Return {region: [orders in that region]}."""
    grouped: Dict[str, List[dict]] = {}
    for order in orders:
        grouped.setdefault(order["region"], []).append(order)
    return grouped


# --------------------------------------------------------------------------
# 4. list vs. set membership timing
# --------------------------------------------------------------------------
def build_synthetic_dataset(size: int) -> List[str]:
    """Build `size` synthetic customer IDs, e.g. 'CUST-000001' ... 'CUST-0NNNNN'."""
    return [f"CUST-{i:06d}" for i in range(size)]


def time_membership_checks(dataset: List[str], lookups: List[str]) -> Dict[str, float]:
    """Time `in` membership checks for `lookups` against `dataset`, as a
    list (O(n) per check) vs. as a set (O(1) average per check)."""
    dataset_as_set = set(dataset)  # building the set costs O(n) once, up front

    start = time.perf_counter()
    for value in lookups:
        _ = value in dataset  # O(n) scan, each time, on the list
    list_elapsed = time.perf_counter() - start

    start = time.perf_counter()
    for value in lookups:
        _ = value in dataset_as_set  # O(1) average lookup, each time, on the set
    set_elapsed = time.perf_counter() - start

    return {"list_seconds": list_elapsed, "set_seconds": set_elapsed}


if __name__ == "__main__":
    print("=== 1. Deduplication with a set ===")
    unique_ids = unique_customer_ids(ORDERS)
    print(f"Total orders: {len(ORDERS)}")
    print(f"Unique customers: {len(unique_ids)} -> {sorted(unique_ids)}\n")

    print("=== 2. Frequency counting with collections.Counter ===")
    region_counts = orders_per_region(ORDERS)
    for region, count in region_counts.most_common():
        print(f"  {region:<6} : {count} order(s)")
    print(f"Busiest region: {region_counts.most_common(1)[0][0]}\n")

    print("=== 3. Grouping by region into a dict of lists ===")
    grouped = group_orders_by_region(ORDERS)
    for region, region_orders in grouped.items():
        order_ids = [o["order_id"] for o in region_orders]
        print(f"  {region:<6} : {order_ids}")
    print()

    print("=== 4. list vs. set membership timing (20,000-item dataset) ===")
    DATASET_SIZE = 20_000
    dataset = build_synthetic_dataset(DATASET_SIZE)

    # Mix of lookups that exist (best/worst case for list scan) and ones that don't.
    lookups = [
        dataset[0],                 # first element - cheap even for a list
        dataset[DATASET_SIZE // 2],  # middle element
        dataset[-1],                 # last element - worst case for a list scan
        "CUST-999999",               # does not exist - list must scan all 20,000
    ] * 250  # repeat the mix 250 times -> 1,000 total lookups, to get a measurable timing

    timings = time_membership_checks(dataset, lookups)
    print(f"Dataset size: {DATASET_SIZE:,} items, {len(lookups):,} membership checks performed")
    print(f"  list membership checks : {timings['list_seconds']:.6f} seconds total")
    print(f"  set  membership checks : {timings['set_seconds']:.6f} seconds total")
    if timings["set_seconds"] > 0:
        speedup = timings["list_seconds"] / timings["set_seconds"]
        print(f"  -> set-based lookups were approximately {speedup:,.0f}x faster than list-based "
              f"lookups for this workload.")
    print("  Takeaway: list membership is O(n) per check (it may scan every element); "
          "set membership is O(1) on average per check, regardless of dataset size.")
