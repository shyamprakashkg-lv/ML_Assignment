"""
Module 12 - Lab 1: Age Calculator CLI
======================================

Task (verbatim from the curriculum):
    "Build a simple CLI tool that prompts the user for their birth year.
    Validate the input to ensure it is a numerical value and calculate
    their current age."

This script:
    1. Prompts the user for a birth year.
    2. Validates that the input is numeric (handles non-numeric input
       gracefully, e.g. "nineteen-ninety" or empty strings).
    3. Validates that the year is a plausible 4-digit year and is not
       in the future.
    4. Loops, re-prompting, until a valid birth year is supplied.
    5. Calculates and reports the current age.

Design note:
    The core validation/age-calculation logic lives in `run_cli()`, which
    takes a single already-captured input string and returns a result -
    it does NOT call input() itself. This makes it fully testable without
    needing real stdin. The retry loop lives in `main()`, which calls
    input() for real interactive use. The demo block at the bottom drives
    `run_cli()` with a sequence of hardcoded strings (some invalid, one
    valid) to show the exact validation behaviour end-to-end, without the
    script ever blocking on real keyboard input.
"""

from dataclasses import dataclass
from datetime import date


MIN_PLAUSIBLE_YEAR = 1900  # nobody alive today was born before this (practical floor)


@dataclass
class AgeResult:
    """Outcome of a single run_cli() call."""
    success: bool
    message: str
    birth_year: int = None
    age: int = None


def calculate_age(birth_year: int, current_year: int = None) -> int:
    """Return the age in whole years for someone born in `birth_year`.

    Using only the year (not full date) keeps this in line with the
    task's scope: "prompts for their birth year ... calculate their
    current age".
    """
    if current_year is None:
        current_year = date.today().year
    return current_year - birth_year


def run_cli(birth_year_input: str) -> AgeResult:
    """Validate one piece of raw input and, if valid, compute the age.

    This function performs NO input()/print() I/O itself, which is what
    makes it safe to call repeatedly with hardcoded strings in tests or
    in the demo block below.
    """
    raw = birth_year_input.strip()

    # 1. Must be numeric at all (handles letters, blanks, symbols, decimals).
    if not raw.isdigit():
        return AgeResult(
            success=False,
            message=f"'{birth_year_input}' is not a valid whole number. "
                     f"Please enter a 4-digit year, e.g. 1990.",
        )

    year = int(raw)
    current_year = date.today().year

    # 2. Must look like a real 4-digit year.
    if len(raw) != 4 or year < MIN_PLAUSIBLE_YEAR:
        return AgeResult(
            success=False,
            message=f"'{birth_year_input}' doesn't look like a valid birth year. "
                     f"Please enter a 4-digit year between {MIN_PLAUSIBLE_YEAR} and {current_year}.",
        )

    # 3. Must not be in the future.
    if year > current_year:
        return AgeResult(
            success=False,
            message=f"{year} is in the future. Please enter a year no later than {current_year}.",
        )

    age = calculate_age(year, current_year)
    return AgeResult(
        success=True,
        message=f"You were born in {year}. Your current age is {age}.",
        birth_year=year,
        age=age,
    )


def main():
    """Real interactive entry point: loops until a valid year is given."""
    print("=== Age Calculator ===")
    while True:
        raw_input_value = input("Enter your birth year (e.g. 1990): ")
        result = run_cli(raw_input_value)
        print(result.message)
        if result.success:
            break


if __name__ == "__main__":
    print("=== Age Calculator CLI - Non-Interactive Demo ===")
    print("(Simulating a user who makes a few mistakes before getting it right)\n")

    simulated_attempts = [
        "nineteen-ninety",  # not numeric at all
        "",                 # blank input
        "95",               # not 4 digits
        "2099",             # in the future
        "1990",             # finally valid
    ]

    for attempt_number, attempt in enumerate(simulated_attempts, start=1):
        print(f"Attempt {attempt_number}: user types '{attempt}'")
        outcome = run_cli(attempt)
        print(f"  -> {outcome.message}")
        if outcome.success:
            print("  -> Valid input received. Loop would exit here in main().")
            break
        else:
            print("  -> Invalid input. Loop would re-prompt in main().")
        print()

    print("\n--- Additional direct checks ---")
    for sample in ["2005", "1900", "1899", "abcd1"]:
        r = run_cli(sample)
        status = "VALID" if r.success else "INVALID"
        print(f"run_cli('{sample}') -> {status}: {r.message}")
