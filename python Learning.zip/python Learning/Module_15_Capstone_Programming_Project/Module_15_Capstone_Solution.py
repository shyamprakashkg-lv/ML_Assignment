"""
Module_15_Capstone_Solution.py

Module 15 - Capstone Programming Project
-----------------------------------------
REFERENCE SOLUTION for the capstone scenario:

    "You are a Data Scientist analyzing e-commerce purchasing behavior
    without relying on external libraries like Pandas. Design a
    CustomerAnalytics class that reads a raw CSV of customer
    transactions. Implement methods to handle missing or corrupted
    monetary values using try/except blocks to impute the dataset's
    average. Use list comprehensions to engineer a new categorical
    feature called 'Recency Status' (Active vs. Dormant) based on the
    days since their last purchase. Finally, segment customers into
    'Premium' and 'Standard' tiers based on lifetime value, apply a
    custom decorator to log the execution time of your analysis, and
    export the finalized feature set to a new file for model
    training."

This file demonstrates, working together on real (synthetic) data,
every skill built up across Modules 10-14:
    - Module 10: a custom decorator (`execution_timer`) using
      functools.wraps + time.perf_counter.
    - Module 11: list/dict comprehensions for feature engineering.
    - Module 12: robust exception handling (try/except) with a safe,
      statistically sound fallback (mean imputation).
    - Module 13: clean, modular, well-documented OOP design.
    - Module 14: end-to-end problem solving, tying it all together.

Usage:
    python3 generate_sample_transactions.py   # produces the input CSV
    python3 Module_15_Capstone_Solution.py     # runs this solution

Output:
    customer_features_output.csv - the finalized, model-training-ready
    feature set (customer_id, lifetime_value, recency_status, tier).
"""

import csv
import functools
import os
import time
from datetime import date, datetime


# ---------------------------------------------------------------------------
# Instrumentation requirement: a custom decorator that logs execution time.
# ---------------------------------------------------------------------------
def execution_timer(func):
    """
    Decorator that measures and logs (prints) how long the wrapped
    function took to run, in seconds, without altering its return
    value or signature.

    Requirement satisfied:
        "...apply a custom decorator to log the execution time of your
        analysis..."
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        print(f"[execution_timer] {func.__name__} took {elapsed:.4f} seconds")
        return result

    return wrapper


class CustomerAnalytics:
    """
    Reads raw e-commerce transaction data from a CSV file (standard
    library only - no Pandas), cleans it, engineers features, segments
    customers, and exports a model-training-ready feature set.

    Expected input CSV columns:
        customer_id, transaction_date (YYYY-MM-DD), amount

    Pipeline (see run_full_analysis):
        load_data -> _clean_monetary_values -> _aggregate_customers
        -> _engineer_recency_status -> _segment_customers
        -> (caller invokes export_features)
    """

    # A customer whose most recent purchase is within this many days of
    # the dataset's latest transaction date is considered "Active";
    # otherwise "Dormant". 90 days (~1 quarter) is a common, documented
    # business rule for e-commerce recency.
    RECENCY_THRESHOLD_DAYS = 90

    # Customers in the top 25% by lifetime value are classified as
    # "Premium"; everyone else is "Standard". Documented here so the
    # business rule is explicit and easy to tune.
    PREMIUM_TOP_QUANTILE = 0.25

    def __init__(self, csv_path):
        """
        Store the path to the raw transactions CSV and initialize the
        instance attributes populated by later pipeline steps.

        Requirement satisfied:
            "Design a CustomerAnalytics class that reads a raw CSV of
            customer transactions."
        """
        self.csv_path = csv_path
        self.raw_rows = []          # list[dict], one dict per transaction
        self.customers = {}         # customer_id -> {lifetime_value, ...}
        self.reference_date = None  # most recent transaction date overall

    # ------------------------------------------------------------------
    # Step 1: Load the raw CSV
    # ------------------------------------------------------------------
    def load_data(self):
        """
        Read self.csv_path with the standard library `csv` module into
        self.raw_rows, parsing each transaction_date into a real
        `date` object. Also determines self.reference_date: the most
        recent transaction date across the whole dataset, used later
        as the anchor for recency calculations.

        Requirement satisfied:
            "...reads a raw CSV of customer transactions."

        Returns:
            list[dict]: the raw rows read from the CSV.
        """
        if not os.path.exists(self.csv_path):
            raise FileNotFoundError(f"Input CSV not found: {self.csv_path}")

        with open(self.csv_path, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        for row in rows:
            row["transaction_date"] = self._parse_date(row["transaction_date"])

        self.raw_rows = rows
        self.reference_date = max(row["transaction_date"] for row in self.raw_rows)
        return self.raw_rows

    @staticmethod
    def _parse_date(date_str):
        """Parse a 'YYYY-MM-DD' string into a date object."""
        return datetime.strptime(date_str.strip(), "%Y-%m-%d").date()

    # ------------------------------------------------------------------
    # Step 2: Clean / impute monetary values
    # ------------------------------------------------------------------
    def _clean_monetary_values(self):
        """
        Convert every row's 'amount' value to a float, using try/except
        to catch missing (empty string) or corrupted (non-numeric,
        e.g. "N/A", "error", "--") values.

        Two-pass approach to avoid the classic pitfall of letting the
        imputed/fallback values leak into the average used to compute
        them:
            1. First pass: try to parse every amount; collect only the
               ones that succeed into `valid_amounts` and compute
               their mean.
            2. Second pass: for every row whose amount failed to
               parse, replace it with that mean (imputed value).

        Requirement satisfied:
            "Implement methods to handle missing or corrupted monetary
            values using try/except blocks to impute the dataset's
            average."

        Returns:
            None. Mutates self.raw_rows in place so every row's
            'amount' is a clean float.
        """
        valid_amounts = []
        parsed_rows = []  # (row, parsed_value_or_None)

        # --- First pass: parse what we can, track failures separately ---
        for row in self.raw_rows:
            raw_value = row["amount"]
            try:
                parsed_value = float(raw_value)
            except (TypeError, ValueError):
                parsed_value = None  # missing/corrupted - fix in pass 2
            else:
                valid_amounts.append(parsed_value)
            parsed_rows.append((row, parsed_value))

        if not valid_amounts:
            # Extremely unlikely with real data, but guard against a
            # fully-corrupted dataset rather than dividing by zero.
            raise ValueError("No valid monetary values found to compute a mean for imputation.")

        mean_amount = sum(valid_amounts) / len(valid_amounts)

        # --- Second pass: impute only the rows that failed to parse ---
        imputed_count = 0
        for row, parsed_value in parsed_rows:
            if parsed_value is None:
                row["amount"] = mean_amount
                imputed_count += 1
            else:
                row["amount"] = parsed_value

        print(f"[_clean_monetary_values] Imputed {imputed_count} missing/corrupted "
              f"amount value(s) using the dataset mean of {mean_amount:.2f}.")

    # ------------------------------------------------------------------
    # Step 3: Aggregate per-customer lifetime value + last purchase date
    # ------------------------------------------------------------------
    def _aggregate_customers(self):
        """
        Build self.customers from the now-clean self.raw_rows: for
        each customer_id, accumulate total lifetime_value (sum of
        amounts) and track their last_purchase_date (max
        transaction_date).

        Requirement satisfied:
            supports "segment customers into 'Premium' and 'Standard'
            tiers based on lifetime value" and the Recency Status
            feature, both of which need these per-customer aggregates.

        Returns:
            None. Populates self.customers in place.
        """
        customers = {}
        for row in self.raw_rows:
            cust_id = row["customer_id"]
            amount = row["amount"]
            tx_date = row["transaction_date"]

            if cust_id not in customers:
                customers[cust_id] = {
                    "lifetime_value": 0.0,
                    "last_purchase_date": tx_date,
                }

            customers[cust_id]["lifetime_value"] += amount
            if tx_date > customers[cust_id]["last_purchase_date"]:
                customers[cust_id]["last_purchase_date"] = tx_date

        # Round lifetime value for clean, readable output.
        for data in customers.values():
            data["lifetime_value"] = round(data["lifetime_value"], 2)

        self.customers = customers

    # ------------------------------------------------------------------
    # Step 4: Engineer the "Recency Status" feature
    # ------------------------------------------------------------------
    def _engineer_recency_status(self):
        """
        Classify every customer as "Active" (last purchase within
        RECENCY_THRESHOLD_DAYS days of self.reference_date) or
        "Dormant" (otherwise), using a LIST COMPREHENSION as required.

        Requirement satisfied:
            "Use list comprehensions to engineer a new categorical
            feature called 'Recency Status' (Active vs. Dormant) based
            on the days since their last purchase."

        Returns:
            None. Adds a "recency_status" key to every entry in
            self.customers.
        """
        # List comprehension building (customer_id, status) pairs based
        # on days-since-last-purchase vs. the recency threshold.
        recency_pairs = [
            (
                cust_id,
                "Active"
                if (self.reference_date - data["last_purchase_date"]).days
                <= self.RECENCY_THRESHOLD_DAYS
                else "Dormant",
            )
            for cust_id, data in self.customers.items()
        ]

        # Fold the comprehension's results back into self.customers.
        for cust_id, status in recency_pairs:
            self.customers[cust_id]["recency_status"] = status

    # ------------------------------------------------------------------
    # Step 5: Segment customers into Premium / Standard tiers
    # ------------------------------------------------------------------
    def _segment_customers(self):
        """
        Assign each customer a "tier" of "Premium" or "Standard" based
        on lifetime_value. Customers in the top PREMIUM_TOP_QUANTILE
        (top 25% by default) of lifetime value are "Premium"; everyone
        else is "Standard". The cutoff is computed from the actual
        distribution of lifetime values in this dataset, so it adapts
        to the data rather than using a hardcoded dollar amount.

        Requirement satisfied:
            "...segment customers into 'Premium' and 'Standard' tiers
            based on lifetime value..."

        Returns:
            None. Adds a "tier" key to every entry in self.customers.
        """
        lifetime_values = sorted(data["lifetime_value"] for data in self.customers.values())
        n = len(lifetime_values)

        # Index marking the start of the top quantile, e.g. top 25%.
        cutoff_index = max(0, int(n * (1 - self.PREMIUM_TOP_QUANTILE)) - 1)
        cutoff_value = lifetime_values[cutoff_index]

        for data in self.customers.values():
            data["tier"] = "Premium" if data["lifetime_value"] >= cutoff_value else "Standard"

    # ------------------------------------------------------------------
    # Orchestration - decorated so the whole pipeline's timing is logged
    # ------------------------------------------------------------------
    @execution_timer
    def run_full_analysis(self):
        """
        Run the full pipeline in order:
            load_data -> _clean_monetary_values -> _aggregate_customers
            -> _engineer_recency_status -> _segment_customers

        Wrapped with @execution_timer so the wall-clock time of the
        entire analysis is logged.

        Requirement satisfied:
            "...apply a custom decorator to log the execution time of
            your analysis..."

        Returns:
            dict: self.customers, the fully processed per-customer
            feature set.
        """
        self.load_data()
        self._clean_monetary_values()
        self._aggregate_customers()
        self._engineer_recency_status()
        self._segment_customers()
        return self.customers

    # ------------------------------------------------------------------
    # Step 6: Export the final feature set
    # ------------------------------------------------------------------
    def export_features(self, output_path):
        """
        Write the finalized per-customer feature set to a new CSV file
        at `output_path` using the standard library `csv` module.

        Output columns:
            customer_id, lifetime_value, recency_status, tier

        Requirement satisfied:
            "...export the finalized feature set to a new file for
            model training."

        Args:
            output_path (str): path to write the output CSV to.

        Returns:
            str: the output_path that was written.
        """
        fieldnames = ["customer_id", "lifetime_value", "recency_status", "tier"]
        with open(output_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for cust_id, data in sorted(
                self.customers.items(), key=lambda kv: kv[1]["lifetime_value"], reverse=True
            ):
                writer.writerow(
                    {
                        "customer_id": cust_id,
                        "lifetime_value": data["lifetime_value"],
                        "recency_status": data["recency_status"],
                        "tier": data["tier"],
                    }
                )
        return output_path


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.abspath(__file__))
    input_csv = os.path.join(script_dir, "customer_transactions.csv")
    output_csv = os.path.join(script_dir, "customer_features_output.csv")

    analytics = CustomerAnalytics(input_csv)
    features = analytics.run_full_analysis()
    analytics.export_features(output_csv)

    n_premium = sum(1 for d in features.values() if d["tier"] == "Premium")
    n_active = sum(1 for d in features.values() if d["recency_status"] == "Active")

    print(f"Processed {len(features)} customers.")
    print(f"  Premium tier: {n_premium}  |  Standard tier: {len(features) - n_premium}")
    print(f"  Active: {n_active}  |  Dormant: {len(features) - n_active}")
    print(f"Feature set exported to: {output_csv}")
