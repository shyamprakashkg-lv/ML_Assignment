"""
generate_sample_transactions.py

Module 15 - Capstone Programming Project
-----------------------------------------
Small, self-contained helper script that generates a SYNTHETIC
`customer_transactions.csv` file so the capstone project can be run
end-to-end without needing any external / real-world data source.

Run it once before working through the capstone:

    python3 generate_sample_transactions.py

It writes `customer_transactions.csv` into the same folder as this
script, with columns:

    customer_id       - repeating IDs so lifetime value aggregation
                         (summing multiple transactions per customer)
                         is meaningful.
    transaction_date   - ISO date string (YYYY-MM-DD). Dates are spread
                         across the last ~400 days so that some
                         customers look "Active" (recent purchase) and
                         others look "Dormant" (no recent purchase).
    amount             - the monetary value of the transaction. A
                         deliberate subset of rows contain missing
                         ("") or corrupted (e.g. "N/A", "error",
                         "--") values so that the capstone's
                         try/except + mean-imputation requirement has
                         real data to work on.

No third-party libraries are required - only the Python standard
library (`csv`, `random`, `datetime`).
"""

import csv
import os
import random
from datetime import date, timedelta

random.seed(42)  # reproducible output for the classroom

OUTPUT_FILENAME = "customer_transactions.csv"
TODAY = date(2026, 11, 25)  # fixed "latest date in the dataset" anchor

# Values that will stand in for "corrupted" / unusable monetary amounts.
CORRUPT_VALUES = ["N/A", "", "error", "--", "unknown", "null"]

# A handful of named customers so the sample data feels realistic, plus
# plain numeric IDs to pad out the row count.
CUSTOMER_IDS = [f"CUST{1000 + i}" for i in range(40)]


def random_date_within(days_back):
    """Return a random date between `days_back` days ago and today."""
    offset = random.randint(0, days_back)
    return TODAY - timedelta(days=offset)


def build_rows(min_rows=150):
    """
    Build a list of transaction rows (as dicts).

    Each customer gets between 2 and 8 transactions so that:
      - Lifetime value (sum of amounts) varies meaningfully per customer.
      - Recency can differ per customer: some customers' MOST RECENT
        transaction is within the last 90 days (-> "Active"), others'
        most recent transaction is older than 90 days (-> "Dormant").
    """
    rows = []

    for cust_id in CUSTOMER_IDS:
        n_transactions = random.randint(2, 8)

        # Decide, per customer, whether their most recent activity
        # should be recent (Active-leaning) or old (Dormant-leaning).
        is_recent_customer = random.random() < 0.55

        for _ in range(n_transactions):
            if is_recent_customer:
                # Most transactions recent, occasional older one.
                tx_date = random_date_within(85) if random.random() < 0.8 else random_date_within(380)
            else:
                # Most transactions old, so last purchase stays old.
                tx_date = random_date_within(380) if random.random() < 0.85 else random_date_within(200)

            # Base purchase amount, roughly log-normal looking spread.
            base_amount = round(random.uniform(15.0, 950.0), 2)

            # ~12% chance of a missing/corrupted monetary value.
            if random.random() < 0.12:
                amount_value = random.choice(CORRUPT_VALUES)
            else:
                amount_value = base_amount

            rows.append(
                {
                    "customer_id": cust_id,
                    "transaction_date": tx_date.isoformat(),
                    "amount": amount_value,
                }
            )

    # Pad out with extra single-off transactions from new customers if we
    # are still under the minimum row requirement.
    extra_idx = 0
    while len(rows) < min_rows:
        cust_id = f"CUST{2000 + extra_idx}"
        tx_date = random_date_within(380)
        amount_value = round(random.uniform(15.0, 950.0), 2)
        if random.random() < 0.12:
            amount_value = random.choice(CORRUPT_VALUES)
        rows.append(
            {
                "customer_id": cust_id,
                "transaction_date": tx_date.isoformat(),
                "amount": amount_value,
            }
        )
        extra_idx += 1

    random.shuffle(rows)
    return rows


def main():
    rows = build_rows(min_rows=150)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(script_dir, OUTPUT_FILENAME)

    fieldnames = ["customer_id", "transaction_date", "amount"]
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    n_customers = len(set(r["customer_id"] for r in rows))
    n_corrupt = sum(1 for r in rows if not _is_clean_number(r["amount"]))

    print(f"Wrote {len(rows)} transaction rows for {n_customers} unique customers to:")
    print(f"  {output_path}")
    print(f"Of those rows, {n_corrupt} have a missing/corrupted 'amount' value "
          f"(for exercising try/except imputation).")


def _is_clean_number(value):
    try:
        float(value)
        return True
    except (TypeError, ValueError):
        return False


if __name__ == "__main__":
    main()
