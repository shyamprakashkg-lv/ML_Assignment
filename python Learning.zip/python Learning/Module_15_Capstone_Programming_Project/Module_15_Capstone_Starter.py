"""
Module_15_Capstone_Starter.py

Module 15 - Capstone Programming Project
-----------------------------------------
REAL-WORLD SCENARIO (your assignment, verbatim):

    You are a Data Scientist analyzing e-commerce purchasing behavior
    without relying on external libraries like Pandas. Design a
    CustomerAnalytics class that reads a raw CSV of customer
    transactions. Implement methods to handle missing or corrupted
    monetary values using try/except blocks to impute the dataset's
    average. Use list comprehensions to engineer a new categorical
    feature called 'Recency Status' (Active vs. Dormant) based on the
    days since their last purchase. Finally, segment customers into
    'Premium' and 'Standard' tiers based on lifetime value, apply a
    custom decorator to log the execution time of your analysis, and
    export the finalized feature set to a new file for model training.

This is the STARTER (skeleton) version of the solution. Every method
has a complete signature and a docstring explaining EXACTLY what it
must do and which requirement it satisfies, but the body only contains
a `# TODO` describing the work and a `raise NotImplementedError`
(or `pass`, where a stub simply needs to exist). Your job, as the
learner, is to fill in each TODO.

This file is NOT expected to run end-to-end yet - running it will
raise NotImplementedError until you complete the TODOs. That is
expected and correct for a starter file. You can still confirm there
are no syntax errors with:

    python3 -m py_compile Module_15_Capstone_Starter.py

Use `customer_transactions.csv` (produced by
`generate_sample_transactions.py`) as your input data.
"""

import csv
import functools
import time


# ---------------------------------------------------------------------------
# TODO (Instrumentation requirement):
#   "...apply a custom decorator to log the execution time of your
#   analysis..."
#
# Implement `execution_timer` as a decorator that:
#   1. Uses `functools.wraps` so the wrapped function keeps its original
#      name/docstring.
#   2. Records a start time with `time.perf_counter()` before calling the
#      wrapped function.
#   3. Calls the wrapped function and captures its return value.
#   4. Records an end time, computes the elapsed duration, and prints (or
#      logs) a message such as:
#          "[execution_timer] run_full_analysis took 0.0123 seconds"
#   5. Returns the wrapped function's original return value unchanged
#      (the timing must be transparent to the caller).
# ---------------------------------------------------------------------------
def execution_timer(func):
    """
    Decorator that logs how long the wrapped function took to execute.

    Requirement satisfied:
        "...apply a custom decorator to log the execution time of your
        analysis..."
    """
    # TODO: implement functools.wraps-based timing decorator.
    raise NotImplementedError("TODO: implement execution_timer decorator")


class CustomerAnalytics:
    """
    Reads raw e-commerce transaction data from a CSV file (no Pandas)
    and produces a cleaned, feature-engineered, segmented dataset ready
    for hand-off to model training.

    Expected input CSV columns:
        customer_id, transaction_date (YYYY-MM-DD), amount

    Attributes you should plan for in __init__:
        csv_path (str)         - path to the raw transactions CSV.
        raw_rows (list[dict])  - the raw rows as read from the CSV.
        customers (dict)       - per-customer aggregated data, keyed by
                                  customer_id, built up across the
                                  pipeline (e.g. lifetime_value,
                                  last_purchase_date, recency_status,
                                  tier).
        reference_date (date)  - the "latest date in the dataset",
                                  used as the anchor for recency
                                  calculations.
        RECENCY_THRESHOLD_DAYS (int) - class-level constant, e.g. 90,
                                  the cutoff between "Active" and
                                  "Dormant".
        PREMIUM_PERCENTILE (float)  - class-level constant describing
                                  how the Premium/Standard cut is
                                  chosen (e.g. top 25% by lifetime
                                  value).
    """

    # TODO: define class-level constants, e.g.
    #   RECENCY_THRESHOLD_DAYS = 90
    #   PREMIUM_TOP_QUANTILE = 0.25

    def __init__(self, csv_path):
        """
        Store the path to the raw transactions CSV and initialize the
        instance attributes that later pipeline steps will populate
        (raw_rows, customers, reference_date, etc.).

        Requirement satisfied:
            "Design a CustomerAnalytics class that reads a raw CSV of
            customer transactions."
        """
        # TODO: store csv_path; initialize self.raw_rows = [],
        # self.customers = {}, self.reference_date = None (or similar).
        raise NotImplementedError("TODO: implement __init__")

    # ------------------------------------------------------------------
    # Step 1: Load the raw CSV
    # ------------------------------------------------------------------
    def load_data(self):
        """
        Open self.csv_path with the standard library `csv` module (NOT
        Pandas) and read every row into self.raw_rows as a list of
        dicts (csv.DictReader is the natural tool here).

        Also determine and store `self.reference_date`: the MOST
        RECENT transaction_date across the whole raw dataset. This is
        the anchor used later to decide "days since last purchase".

        Requirement satisfied:
            "...reads a raw CSV of customer transactions."

        Returns:
            list[dict]: the raw rows read from the CSV (also stored on
            self.raw_rows).
        """
        # TODO: use csv.DictReader to read self.csv_path into
        # self.raw_rows. Parse each transaction_date string into a
        # date object (consider a small private helper). Compute
        # self.reference_date = max(all transaction dates).
        raise NotImplementedError("TODO: implement load_data")

    # ------------------------------------------------------------------
    # Step 2: Clean / impute monetary values
    # ------------------------------------------------------------------
    def _clean_monetary_values(self):
        """
        Walk through self.raw_rows and convert every 'amount' value to
        a float. Use a try/except block around the conversion: when a
        value is missing (empty string) or corrupted (non-numeric,
        e.g. "N/A", "error", "--"), catching the resulting
        ValueError/TypeError.

        IMPORTANT (common pitfall to avoid): compute the mean used for
        imputation from ONLY the rows whose amount parsed successfully
        (the "valid" values) - do NOT include the corrupted/missing
        rows in that average, and do NOT recompute the mean using
        values you have already imputed.

        A practical two-pass approach:
            1. First pass: try to parse every amount; collect the
               ones that succeed into a list of valid floats and
               compute their mean.
            2. Second pass: for every row that failed to parse, set
               its amount to that mean (the imputed value).

        Requirement satisfied:
            "Implement methods to handle missing or corrupted monetary
            values using try/except blocks to impute the dataset's
            average."

        Returns:
            None. Mutates self.raw_rows in place so every row's
            'amount' is a clean float.
        """
        # TODO: implement the two-pass try/except + mean-imputation
        # logic described above.
        raise NotImplementedError("TODO: implement _clean_monetary_values")

    # ------------------------------------------------------------------
    # Step 3: Aggregate per-customer lifetime value + last purchase date
    # ------------------------------------------------------------------
    def _aggregate_customers(self):
        """
        Using the now-clean self.raw_rows, build self.customers: a
        dict keyed by customer_id, where each value is a dict holding
        at least:
            - "lifetime_value": sum of that customer's amounts.
            - "last_purchase_date": the most recent transaction_date
              for that customer (a date object).

        Requirement satisfied:
            supports "segment customers into 'Premium' and 'Standard'
            tiers based on lifetime value" and the Recency Status
            feature (both need per-customer aggregates first).

        Returns:
            None. Populates self.customers in place.
        """
        # TODO: iterate self.raw_rows, accumulate lifetime_value per
        # customer_id, and track the max transaction_date per
        # customer_id.
        raise NotImplementedError("TODO: implement _aggregate_customers")

    # ------------------------------------------------------------------
    # Step 4: Engineer the "Recency Status" feature
    # ------------------------------------------------------------------
    def _engineer_recency_status(self):
        """
        For every customer in self.customers, compute the number of
        days between self.reference_date and that customer's
        last_purchase_date, then classify it as "Active" (within
        RECENCY_THRESHOLD_DAYS days) or "Dormant" (otherwise).

        You MUST use a LIST COMPREHENSION to perform this
        classification (e.g. build a list of
        (customer_id, recency_status) pairs via a comprehension, then
        fold that list back into self.customers), rather than a plain
        for-loop with .append().

        Requirement satisfied:
            "Use list comprehensions to engineer a new categorical
            feature called 'Recency Status' (Active vs. Dormant) based
            on the days since their last purchase."

        Returns:
            None. Adds a "recency_status" key to every entry in
            self.customers.
        """
        # TODO: compute (customer_id, "Active"/"Dormant") pairs with a
        # list comprehension, then write them back into
        # self.customers[customer_id]["recency_status"].
        raise NotImplementedError("TODO: implement _engineer_recency_status")

    # ------------------------------------------------------------------
    # Step 5: Segment customers into Premium / Standard tiers
    # ------------------------------------------------------------------
    def _segment_customers(self):
        """
        Using each customer's lifetime_value, assign a "tier" of
        either "Premium" or "Standard". Document and use a clear,
        reproducible threshold - e.g. customers whose lifetime_value
        places them in the top PREMIUM_TOP_QUANTILE (top 25%) of all
        customers are "Premium"; everyone else is "Standard".

        Requirement satisfied:
            "...segment customers into 'Premium' and 'Standard' tiers
            based on lifetime value..."

        Returns:
            None. Adds a "tier" key to every entry in self.customers.
        """
        # TODO: sort customers by lifetime_value, determine the
        # Premium cutoff value, then assign "tier" to every customer.
        raise NotImplementedError("TODO: implement _segment_customers")

    # ------------------------------------------------------------------
    # Orchestration - this is the method the decorator should wrap
    # ------------------------------------------------------------------
    # TODO: apply @execution_timer to this method once it is
    # implemented, so the whole analysis pipeline's wall-clock time is
    # logged.
    def run_full_analysis(self):
        """
        Run the full pipeline in order:
            load_data -> _clean_monetary_values -> _aggregate_customers
            -> _engineer_recency_status -> _segment_customers

        This is the method that should be wrapped with
        `@execution_timer` so that timing the "analysis" covers the
        whole pipeline, not just one step.

        Requirement satisfied:
            "...apply a custom decorator to log the execution time of
            your analysis..." (this is the "analysis" being timed).

        Returns:
            dict: self.customers, the fully processed per-customer
            feature set.
        """
        # TODO: call the pipeline steps in order and return
        # self.customers.
        raise NotImplementedError("TODO: implement run_full_analysis")

    # ------------------------------------------------------------------
    # Step 6: Export the final feature set
    # ------------------------------------------------------------------
    def export_features(self, output_path):
        """
        Write the finalized per-customer feature set to a NEW CSV file
        at `output_path`, using the standard library `csv` module.

        Output columns (recommended):
            customer_id, lifetime_value, recency_status, tier

        Requirement satisfied:
            "...export the finalized feature set to a new file for
            model training."

        Args:
            output_path (str): path to write the output CSV to.

        Returns:
            str: the output_path that was written.
        """
        # TODO: use csv.writer or csv.DictWriter to write one row per
        # customer in self.customers to output_path.
        raise NotImplementedError("TODO: implement export_features")


if __name__ == "__main__":
    # This shows how the finished CustomerAnalytics class is meant to
    # be invoked once every TODO above is implemented. Running this
    # file as-is will raise NotImplementedError - that's expected for
    # a starter file.
    analytics = CustomerAnalytics("customer_transactions.csv")
    features = analytics.run_full_analysis()
    analytics.export_features("customer_features_output.csv")
    print(f"Processed {len(features)} customers.")
