"""
Module 10 - Advanced Python Programming
Lab 3: Iterators and Comprehensions Practice
=============================================

This lab is supporting practice material (authored for this module, not
from the official exercise bank) covering two of the module's core topics:

  (a) Building a custom iterator class that implements the iterator
      protocol (__iter__ / __next__ / StopIteration).
  (b) A set of before/after drills contrasting a manual loop with the
      equivalent, more Pythonic list/dict/set comprehension.

HINTS
-----
- An iterator class needs __iter__ (returning self) and __next__ (either
  returning the next value, or raising StopIteration once exhausted).
- A comprehension is just a loop + accumulation expressed declaratively;
  translate "what would the manual loop do" into "what condition/expression
  describes each kept/produced item" to find the comprehension form.

LEARNING GOAL
-------------
Be comfortable both consuming AND building iterators, and recognize when a
comprehension genuinely improves readability over a manual loop (as opposed
to when it would hurt readability and a loop should be kept instead).
"""


# ===========================================================================
# PART A: Custom Iterator Class
# ===========================================================================

class Countdown:
    """A custom iterator that counts down from `start` to 1 (inclusive).

    Implements the full iterator protocol:
      - __iter__ returns the iterator object itself, which is what lets a
        Countdown instance be used directly in a `for` loop or passed to
        list()/sum()/etc.
      - __next__ returns the next value in the sequence, or raises
        StopIteration once the countdown reaches zero, which is the
        standard signal that tells any consumer (for-loop, list(), ...)
        to stop requesting more values.
    """

    def __init__(self, start):
        if start < 0:
            raise ValueError("start must be a non-negative integer")
        self.current = start

    def __iter__(self):
        return self

    def __next__(self):
        if self.current <= 0:
            raise StopIteration
        value = self.current
        self.current -= 1
        return value


class PaginatedResults:
    """A second, more realistic custom iterator: simulates paginating
    through a result set (e.g. an API response) a fixed page size at a
    time, without ever materializing the full result set in memory.

    This mirrors the "paginated API result iterator" real-world example
    used elsewhere in this module.
    """

    def __init__(self, all_items, page_size):
        self._all_items = all_items
        self._page_size = page_size
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index >= len(self._all_items):
            raise StopIteration
        page = self._all_items[self._index: self._index + self._page_size]
        self._index += self._page_size
        return page


# ===========================================================================
# PART B: Comprehension Drills (manual loop "before" vs. comprehension "after")
# ===========================================================================

def drill_1_square_evens(numbers):
    """Drill 1: Square every EVEN number in a list."""
    # --- Before: manual loop ---
    before_result = []
    for n in numbers:
        if n % 2 == 0:
            before_result.append(n * n)

    # --- After: list comprehension ---
    after_result = [n * n for n in numbers if n % 2 == 0]

    return before_result, after_result


def drill_2_word_lengths(words):
    """Drill 2: Build a dict mapping each word to its length."""
    # --- Before: manual loop ---
    before_result = {}
    for word in words:
        before_result[word] = len(word)

    # --- After: dict comprehension ---
    after_result = {word: len(word) for word in words}

    return before_result, after_result


def drill_3_unique_domains(emails):
    """Drill 3: Extract the set of UNIQUE email domains from a list of
    email addresses (duplicates collapsed automatically by a set)."""
    # --- Before: manual loop ---
    before_result = set()
    for email in emails:
        domain = email.split("@")[1].lower()
        before_result.add(domain)

    # --- After: set comprehension ---
    after_result = {email.split("@")[1].lower() for email in emails}

    return before_result, after_result


def drill_4_flatten_matrix(matrix):
    """Drill 4: Flatten a 2D matrix (list of lists) into a single 1D list,
    keeping only values greater than 0 - demonstrates a nested-for
    comprehension combined with a filter condition."""
    # --- Before: manual nested loop ---
    before_result = []
    for row in matrix:
        for value in row:
            if value > 0:
                before_result.append(value)

    # --- After: nested comprehension with filter ---
    after_result = [value for row in matrix for value in row if value > 0]

    return before_result, after_result


if __name__ == "__main__":
    print("=" * 70)
    print("PART A1: Countdown custom iterator")
    print("=" * 70)
    countdown_values = []
    for n in Countdown(5):
        countdown_values.append(n)
    print(f"Countdown(5) produced: {countdown_values}")
    assert countdown_values == [5, 4, 3, 2, 1]
    print("Correctness check passed: [5, 4, 3, 2, 1]\n")

    # Demonstrate that it also works with list() and sum() since it is a
    # proper iterator, not just something usable in a 'for' loop.
    print(f"list(Countdown(3))     = {list(Countdown(3))}")
    print(f"sum(Countdown(4))      = {sum(Countdown(4))}  (4+3+2+1)\n")

    print("=" * 70)
    print("PART A2: PaginatedResults custom iterator")
    print("=" * 70)
    all_records = [f"record-{i}" for i in range(1, 12)]  # 11 records
    pages = list(PaginatedResults(all_records, page_size=4))
    print(f"11 records paginated with page_size=4 -> {len(pages)} pages:")
    for i, page in enumerate(pages, 1):
        print(f"  Page {i}: {page}")
    assert pages == [
        all_records[0:4], all_records[4:8], all_records[8:12]
    ]
    print("Correctness check passed: pages reconstruct the original list.\n")

    print("=" * 70)
    print("PART B1: Square even numbers - manual loop vs. comprehension")
    print("=" * 70)
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    before, after = drill_1_square_evens(numbers)
    print(f"Input:        {numbers}")
    print(f"Before (loop): {before}")
    print(f"After (comp):  {after}")
    assert before == after == [4, 16, 36, 64, 100]
    print("Correctness check passed: both approaches agree.\n")

    print("=" * 70)
    print("PART B2: Word -> length mapping - manual loop vs. comprehension")
    print("=" * 70)
    words = ["python", "decorator", "generator", "iterator", "ETL"]
    before, after = drill_2_word_lengths(words)
    print(f"Input:        {words}")
    print(f"Before (loop): {before}")
    print(f"After (comp):  {after}")
    assert before == after == {
        "python": 6, "decorator": 9, "generator": 9, "iterator": 8, "ETL": 3
    }
    print("Correctness check passed: both approaches agree.\n")

    print("=" * 70)
    print("PART B3: Unique email domains - manual loop vs. comprehension")
    print("=" * 70)
    emails = ["a@acme.com", "b@acme.com", "c@Beta.io", "d@beta.io", "e@gamma.net"]
    before, after = drill_3_unique_domains(emails)
    print(f"Input:        {emails}")
    print(f"Before (loop): {sorted(before)}")
    print(f"After (comp):  {sorted(after)}")
    assert before == after == {"acme.com", "beta.io", "gamma.net"}
    print("Correctness check passed: both approaches agree.\n")

    print("=" * 70)
    print("PART B4: Flatten matrix, keep positives - manual loop vs. nested comp")
    print("=" * 70)
    matrix = [[1, -2, 3], [-4, 5, 0], [6, -7, 8]]
    before, after = drill_4_flatten_matrix(matrix)
    print(f"Input:        {matrix}")
    print(f"Before (loop): {before}")
    print(f"After (comp):  {after}")
    assert before == after == [1, 3, 5, 6, 8]
    print("Correctness check passed: both approaches agree.\n")

    print("All Lab 3 demonstrations completed successfully.")
