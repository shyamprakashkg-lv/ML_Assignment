"""
Module 10 - Advanced Python Programming
Lab 1: Execution Timer Decorator
=================================

PROBLEM (verbatim task)
-----------------------
Create a custom @execution_timer decorator that prints the time it takes for
any function it decorates to execute. Apply it to a function simulating a
long-running data fetch.

HINTS
-----
- Use functools.wraps so the decorated function keeps its original __name__,
  __doc__, and other metadata (otherwise introspection and debugging tools
  see "wrapper" instead of the real function name).
- Use time.perf_counter() rather than time.time() for measuring durations:
  perf_counter() uses the highest-resolution monotonic clock available and
  is never affected by system clock adjustments (NTP sync, DST, etc.),
  making it the correct tool for benchmarking code execution.
- The wrapper must accept *args and **kwargs so it works for ANY decorated
  function signature, including ones that take positional and/or keyword
  arguments.
- Make sure the wrapper still returns the original function's result -
  a decorator that "swallows" the return value silently breaks every
  caller that depends on it.

LEARNING GOAL
-------------
Understand how a decorator wraps a function to add cross-cutting behavior
(timing, in this case) without touching the business logic inside the
decorated function itself - and understand why functools.wraps matters.
"""

import functools
import random
import time


def execution_timer(func):
    """Decorator that prints how long `func` took to execute.

    Works transparently for any callable regardless of its argument
    signature or return type, and preserves the wrapped function's
    identity (__name__, __doc__, __module__, ...) via functools.wraps.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # perf_counter() is a monotonic, high-resolution clock ideal for
        # measuring short-to-medium elapsed durations. We capture it
        # immediately before and after the call so the measured window is
        # as tight as possible around the actual function execution.
        start = time.perf_counter()
        try:
            result = func(*args, **kwargs)
        finally:
            # Using try/finally guarantees we still report the elapsed
            # time (and don't swallow the exception) even if `func` raises.
            elapsed = time.perf_counter() - start
            print(f"[execution_timer] {func.__name__}() took {elapsed:.4f} seconds")
        return result

    return wrapper


# ---------------------------------------------------------------------------
# Demonstration functions
# ---------------------------------------------------------------------------

@execution_timer
def fetch_customer_data(customer_id):
    """Simulate a long-running data fetch (e.g. a slow DB/API call).

    Takes an argument, which proves the decorator forwards positional
    arguments correctly through *args.
    """
    print(f"Fetching data for customer_id={customer_id} ...")
    # Simulate network/disk latency with a short sleep.
    time.sleep(random.uniform(0.2, 0.5))
    return {"customer_id": customer_id, "name": "Jane Doe", "status": "active"}


@execution_timer
def compute_report_total(*line_items, tax_rate=0.0):
    """Simulate a CPU-bound computation over a variable number of line items.

    Takes *args AND a keyword argument, proving the decorator forwards
    both positional and keyword arguments correctly.
    """
    subtotal = sum(line_items)
    total = subtotal * (1 + tax_rate)
    # A tiny busy-loop to make the timing measurement non-trivial/non-zero.
    _ = [i * i for i in range(200_000)]
    return round(total, 2)


@execution_timer
def simulate_io_bound_fetch(seconds):
    """Simulate an I/O-bound operation (e.g. waiting on a network response)
    using time.sleep() so the decorator's timing reflects real wall-clock
    wait time, not CPU time.
    """
    time.sleep(seconds)
    return f"Fetched payload after waiting {seconds}s"


if __name__ == "__main__":
    print("=" * 70)
    print("DEMO 1: Simulated long-running data fetch (function WITH an argument)")
    print("=" * 70)
    customer = fetch_customer_data(101)
    print(f"Result: {customer}\n")

    print("=" * 70)
    print("DEMO 2: CPU-bound computation (positional *args + keyword arg)")
    print("=" * 70)
    total = compute_report_total(120.50, 75.00, 19.99, tax_rate=0.08)
    print(f"Result: invoice total = {total}\n")

    print("=" * 70)
    print("DEMO 3: I/O-bound operation simulated via time.sleep()")
    print("=" * 70)
    payload = simulate_io_bound_fetch(0.3)
    print(f"Result: {payload}\n")

    print("=" * 70)
    print("Confirming functools.wraps preserved function metadata:")
    print("=" * 70)
    print(f"fetch_customer_data.__name__ = {fetch_customer_data.__name__!r}")
    print(f"fetch_customer_data.__doc__  = {fetch_customer_data.__doc__!r}")
