"""
Module 10 - Advanced Python Programming
Lab 2: Error Log Generator
===========================

PROBLEM (verbatim task)
-----------------------
Write a generator function that reads a massive log file line-by-line and
yields only the lines containing the word 'ERROR', ensuring the program is
memory-efficient.

HINTS
-----
- Opening a file with `for line in file_object:` already streams the file
  one line at a time from disk - it does NOT read the whole file into
  memory first. Avoid file_object.readlines(), which loads every line into
  a Python list upfront and defeats the whole point of this exercise.
- Wrap that streaming loop in a function that uses `yield` instead of
  building and returning a list. That turns the function into a generator:
  calling it returns a lazy iterator, and no work happens until something
  actually iterates over it.
- Because only ONE line is ever held in memory at a time (plus whatever
  small amount of state the generator itself keeps), this approach scales
  to log files of any size - megabytes, gigabytes, or more - with constant
  memory usage.

LEARNING GOAL
-------------
Understand why generators are the standard tool for processing data sets
that are too large to comfortably fit in memory, and see the concrete
memory-efficiency difference between a generator-based approach and a
naive "load everything into a list" approach.
"""

import os
import random
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SAMPLE_LOG_PATH = os.path.join(SCRIPT_DIR, "sample_app.log")

NUM_LINES = 5000  # "massive" is simulated here with a few thousand lines
LEVELS = ["INFO", "WARNING", "ERROR"]
# Weighted so ERROR lines are a realistic minority of total traffic.
LEVEL_WEIGHTS = [0.75, 0.15, 0.10]

COMPONENTS = ["auth-service", "payments-api", "order-worker", "cache-layer", "scheduler"]

INFO_MESSAGES = [
    "Request completed successfully",
    "Cache hit for key user:{n}",
    "Health check passed",
    "Scheduled job started",
    "User {n} logged in",
]
WARNING_MESSAGES = [
    "Response time exceeded 500ms threshold",
    "Retrying connection to downstream service (attempt {n})",
    "Deprecated API endpoint called",
    "Queue depth above normal watermark: {n} items",
]
ERROR_MESSAGES = [
    "Database connection timeout after 30s",
    "Unhandled exception in request handler: KeyError('{n}')",
    "Payment gateway returned HTTP 500",
    "Failed to acquire lock on resource {n}",
    "NullPointerException processing order {n}",
    "Out of memory while processing batch {n}",
]


def _generate_sample_log(path, num_lines=NUM_LINES, seed=42):
    """Create a synthetic, multi-thousand-line log file with a realistic
    mix of INFO/WARNING/ERROR lines and timestamps, if one doesn't already
    exist. This stands in for a "massive log file" we don't actually have
    on disk, so the rest of the lab has real data to stream through.
    """
    rng = random.Random(seed)
    start_time = datetime(2026, 11, 1, 0, 0, 0)

    with open(path, "w", encoding="utf-8") as f:
        timestamp = start_time
        for _ in range(num_lines):
            timestamp += timedelta(seconds=rng.randint(1, 45))
            level = rng.choices(LEVELS, weights=LEVEL_WEIGHTS, k=1)[0]
            component = rng.choice(COMPONENTS)
            n = rng.randint(1, 9999)

            if level == "INFO":
                msg = rng.choice(INFO_MESSAGES).format(n=n)
            elif level == "WARNING":
                msg = rng.choice(WARNING_MESSAGES).format(n=n)
            else:
                msg = rng.choice(ERROR_MESSAGES).format(n=n)

            ts_str = timestamp.strftime("%Y-%m-%d %H:%M:%S")
            f.write(f"{ts_str} [{level}] ({component}) {msg}\n")


def error_line_generator(log_path):
    """Generator function: yields only the lines in `log_path` that contain
    the word 'ERROR', one at a time.

    MEMORY EFFICIENCY EXPLANATION
    ------------------------------
    `for line in f:` relies on the file object's own iterator protocol,
    which reads and returns ONE line from disk per iteration. Because this
    function uses `yield` instead of accumulating matches into a list, the
    ENTIRE log file is never resident in memory at once - at any given
    moment, memory usage is roughly O(1): just the current line plus a
    small, fixed amount of generator bookkeeping state. This holds true
    whether the log file is 5,000 lines or 5 billion lines, which is
    exactly what makes this approach appropriate for "massive" log files
    that would not fit in RAM if read via file.readlines() or similar.
    """
    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:                  # streamed one line at a time from disk
            if "ERROR" in line:
                yield line.rstrip("\n")  # pause here; resumes on the next next()


def naive_error_lines(log_path):
    """Contrast function (NOT recommended) - loads the ENTIRE file into a
    list in memory before filtering. Included only to demonstrate the
    difference; do not use this pattern on genuinely large files.
    """
    with open(log_path, "r", encoding="utf-8") as f:
        all_lines = f.readlines()          # <-- entire file materialized in RAM
    return [line.rstrip("\n") for line in all_lines if "ERROR" in line]


if __name__ == "__main__":
    print("=" * 70)
    print("STEP 1: Ensure the synthetic sample log file exists")
    print("=" * 70)
    if not os.path.exists(SAMPLE_LOG_PATH):
        print(f"Generating sample log at: {SAMPLE_LOG_PATH}")
        _generate_sample_log(SAMPLE_LOG_PATH)
    else:
        print(f"Sample log already exists at: {SAMPLE_LOG_PATH} (reusing it)")

    file_size_kb = os.path.getsize(SAMPLE_LOG_PATH) / 1024
    print(f"Log file size: {file_size_kb:.1f} KB, {NUM_LINES} lines\n")

    print("=" * 70)
    print("STEP 2: Stream the log file through the generator, printing only")
    print("        ERROR lines (first 15 shown to keep output readable)")
    print("=" * 70)
    error_count = 0
    for i, error_line in enumerate(error_line_generator(SAMPLE_LOG_PATH), 1):
        error_count += 1
        if i <= 15:
            print(error_line)
    print(f"... ({error_count} total ERROR lines found via the memory-efficient "
          f"generator)\n")

    print("=" * 70)
    print("STEP 3: Cross-check against the naive (non-memory-efficient) "
          "approach")
    print("=" * 70)
    naive_result = naive_error_lines(SAMPLE_LOG_PATH)
    print(f"Naive readlines()-based approach found: {len(naive_result)} ERROR lines")
    assert error_count == len(naive_result), "Mismatch between generator and naive results!"
    print("Match confirmed: both approaches agree on the same ERROR lines.\n")

    print("=" * 70)
    print("WHY THE GENERATOR APPROACH IS MEMORY-EFFICIENT")
    print("=" * 70)
    print(
        "The naive_error_lines() function calls f.readlines(), which reads the\n"
        "WHOLE file into a Python list before any filtering happens - memory use\n"
        "scales linearly with file size (O(n)). error_line_generator(), by\n"
        "contrast, uses `yield` inside a `for line in f:` loop, so it only ever\n"
        "holds ONE line in memory at a time - memory use stays constant (O(1))\n"
        "regardless of whether the log file has five thousand lines or five\n"
        "billion. This is why generators are the standard tool for streaming\n"
        "large files, logs, and datasets that do not comfortably fit in RAM."
    )
