"""
Module 14 - Python Certification Readiness
Lab 2: Code Tracing Challenges

At least 8 "predict the exact output" code-tracing challenges. Each challenge:
  (a) is printed as a snippet string for the learner to read and guess first,
  (b) is then ACTUALLY executed (via a function call with stdout captured, or
      via exec()), so the "correct" output shown is never hand-guessed, and
  (c) the real captured output is printed next to an explanation of WHY.

Because the output is captured from real execution rather than typed in by
hand, this script is simultaneously the practice material and its own
verified answer key.

Run with:  python3 Module_14_Lab2_Code_Tracing_Challenges.py
"""

import copy
import io
import contextlib


def capture_stdout(func, *args, **kwargs):
    """Run func(*args, **kwargs), capturing anything it prints, and return
    (return_value, captured_text)."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        result = func(*args, **kwargs)
    return result, buf.getvalue()


# --------------------------------------------------------------------------
# Challenge 1: Mutable default argument
# --------------------------------------------------------------------------
CHALLENGE_1_SNIPPET = '''\
def add_item(item, basket=[]):
    basket.append(item)
    return basket

print(add_item("apple"))
print(add_item("banana"))
'''


def challenge_1():
    def add_item(item, basket=[]):
        basket.append(item)
        return basket

    print(add_item("apple"))
    print(add_item("banana"))


# --------------------------------------------------------------------------
# Challenge 2: Shallow copy vs deep copy
# --------------------------------------------------------------------------
CHALLENGE_2_SNIPPET = '''\
import copy

original = [[1, 2], [3, 4]]
shallow = copy.copy(original)
deep = copy.deepcopy(original)

shallow[0].append(99)
deep[1].append(99)

print("original:", original)
print("shallow:", shallow)
print("deep:", deep)
'''


def challenge_2():
    original = [[1, 2], [3, 4]]
    shallow = copy.copy(original)
    deep = copy.deepcopy(original)

    shallow[0].append(99)
    deep[1].append(99)

    print("original:", original)
    print("shallow:", shallow)
    print("deep:", deep)


# --------------------------------------------------------------------------
# Challenge 3: `is` vs `==`
# --------------------------------------------------------------------------
CHALLENGE_3_SNIPPET = '''\
a = [1, 2, 3]
b = [1, 2, 3]
c = a

print(a == b)
print(a is b)
print(a is c)

x = 256
y = 256
print(x is y)

p = 1000
q = 1000
print(p is q)
'''


def challenge_3():
    a = [1, 2, 3]
    b = [1, 2, 3]
    c = a

    print(a == b)
    print(a is b)
    print(a is c)

    x = 256
    y = 256
    print(x is y)

    p = 1000
    q = 1000
    print(p is q)


# --------------------------------------------------------------------------
# Challenge 4: Integer division `/` vs `//`
# --------------------------------------------------------------------------
CHALLENGE_4_SNIPPET = '''\
print(7 / 2)
print(7 // 2)
print(-7 // 2)
print(-7 / 2)
print(7 % -2)
'''


def challenge_4():
    print(7 / 2)
    print(7 // 2)
    print(-7 // 2)
    print(-7 / 2)
    print(7 % -2)


# --------------------------------------------------------------------------
# Challenge 5: for...else
# --------------------------------------------------------------------------
CHALLENGE_5_SNIPPET = '''\
def find_first_even(nums):
    for n in nums:
        if n % 2 == 0:
            print(f"found even: {n}")
            break
    else:
        print("no even number found")

find_first_even([1, 3, 5, 7])
find_first_even([1, 3, 4, 7])
'''


def challenge_5():
    def find_first_even(nums):
        for n in nums:
            if n % 2 == 0:
                print(f"found even: {n}")
                break
        else:
            print("no even number found")

    find_first_even([1, 3, 5, 7])
    find_first_even([1, 3, 4, 7])


# --------------------------------------------------------------------------
# Challenge 6: Variable scope / LEGB (UnboundLocalError)
# --------------------------------------------------------------------------
CHALLENGE_6_SNIPPET = '''\
count = 100

def show_then_fail():
    print(count)      # which 'count' does this refer to?
    count = count + 1  # this line makes count LOCAL to the whole function

try:
    show_then_fail()
except UnboundLocalError as e:
    print(f"UnboundLocalError: {e}")
'''


def challenge_6():
    count = 100

    def show_then_fail():
        print(count)
        count = count + 1

    try:
        show_then_fail()
    except UnboundLocalError as e:
        print(f"UnboundLocalError: {e}")


# --------------------------------------------------------------------------
# Challenge 7: String immutability
# --------------------------------------------------------------------------
CHALLENGE_7_SNIPPET = '''\
s = "hello"
s_upper = s.upper()
print(s)
print(s_upper)
print(s is s_upper)

try:
    s[0] = "H"
except TypeError as e:
    print(f"TypeError: {e}")
'''


def challenge_7():
    s = "hello"
    s_upper = s.upper()
    print(s)
    print(s_upper)
    print(s is s_upper)

    try:
        s[0] = "H"
    except TypeError as e:
        print(f"TypeError: {e}")


# --------------------------------------------------------------------------
# Challenge 8: Generator laziness
# --------------------------------------------------------------------------
CHALLENGE_8_SNIPPET = '''\
def gen():
    print("start")
    yield 1
    print("middle")
    yield 2
    print("end")

g = gen()
print("generator created, nothing printed yet")
print(next(g))
print(next(g))
'''


def challenge_8():
    def gen():
        print("start")
        yield 1
        print("middle")
        yield 2
        print("end")

    g = gen()
    print("generator created, nothing printed yet")
    print(next(g))
    print(next(g))


# --------------------------------------------------------------------------
# Challenge 9 (bonus): Operator precedence surprise
# --------------------------------------------------------------------------
CHALLENGE_9_SNIPPET = '''\
print(-2 ** 2)
print((-2) ** 2)
print(2 + 3 * 4)
print(not True == False)
'''


def challenge_9():
    print(-2 ** 2)
    print((-2) ** 2)
    print(2 + 3 * 4)
    print(not True == False)


CHALLENGES = [
    {
        "title": "Challenge 1: Mutable Default Argument",
        "snippet": CHALLENGE_1_SNIPPET,
        "func": challenge_1,
        "explanation": (
            "The default list `basket=[]` is created ONCE when add_item is defined, not on every "
            "call. Both calls (with no basket argument) share and mutate that SAME list object, so "
            "the second call's result includes both 'apple' and 'banana'."
        ),
    },
    {
        "title": "Challenge 2: Shallow Copy vs Deep Copy",
        "snippet": CHALLENGE_2_SNIPPET,
        "func": challenge_2,
        "explanation": (
            "copy.copy() is shallow: the outer list is new, but its nested lists are the SAME objects "
            "as in `original`, so mutating shallow[0] also changes original[0]. copy.deepcopy() "
            "recursively duplicates everything, so mutating deep[1] leaves `original` untouched."
        ),
    },
    {
        "title": "Challenge 3: `is` vs `==`",
        "snippet": CHALLENGE_3_SNIPPET,
        "func": challenge_3,
        "explanation": (
            "a == b is True (same values) but a is b is False (different list objects); a is c is "
            "True because c was assigned directly from a (same object). Small integers (-5 to 256) "
            "are always cached by CPython, so 256 is 256 is True. p is q for 1000 ALSO prints True "
            "here, but for an implementation-specific reason, not the small-int cache: CPython's "
            "compiler folds repeated identical integer literals within the same code block into one "
            "shared constant. This is exactly why `is` must never be used to compare values — its "
            "result for numbers/strings depends on caching/interning details that are not guaranteed "
            "by the language and can differ by context (e.g. values received from input() or built "
            "dynamically at runtime, or across different Python implementations, will NOT share "
            "identity this way). Always use `==` for value comparisons."
        ),
    },
    {
        "title": "Challenge 4: Integer Division `/` vs `//`",
        "snippet": CHALLENGE_4_SNIPPET,
        "func": challenge_4,
        "explanation": (
            "`/` is true division and always returns a float. `//` floors toward negative infinity, "
            "not toward zero, so -7 // 2 is -4 (not -3). `%` takes the sign of the divisor, so "
            "7 % -2 is -1, not 1."
        ),
    },
    {
        "title": "Challenge 5: for...else",
        "snippet": CHALLENGE_5_SNIPPET,
        "func": challenge_5,
        "explanation": (
            "The first call never finds an even number, so the loop completes without `break` and "
            "its `else` clause runs ('no even number found'). The second call finds 4, prints the "
            "found message, and `break`s — skipping the `else` clause entirely."
        ),
    },
    {
        "title": "Challenge 6: Variable Scope / LEGB",
        "snippet": CHALLENGE_6_SNIPPET,
        "func": challenge_6,
        "explanation": (
            "Because `count` is assigned somewhere inside show_then_fail, Python treats `count` as a "
            "LOCAL variable for the function's ENTIRE body. The `print(count)` line therefore refers "
            "to the local (not-yet-assigned) `count`, raising UnboundLocalError before the outer, "
            "global `count` is ever consulted."
        ),
    },
    {
        "title": "Challenge 7: String Immutability",
        "snippet": CHALLENGE_7_SNIPPET,
        "func": challenge_7,
        "explanation": (
            "s.upper() returns a brand-new string object; the original `s` is untouched, and "
            "`s is s_upper` is False since they're different objects. Attempting `s[0] = 'H'` raises "
            "TypeError because strings do not support item assignment — there is no way to mutate a "
            "string in place."
        ),
    },
    {
        "title": "Challenge 8: Generator Laziness",
        "snippet": CHALLENGE_8_SNIPPET,
        "func": challenge_8,
        "explanation": (
            "Calling gen() only creates the generator object; none of the function body runs until "
            "iterated. The first next(g) runs up to and including the first yield (printing 'start' "
            "then yielding 1); the second next(g) resumes right after that yield, printing 'middle' "
            "then yielding 2. 'end' never prints because we only call next() twice."
        ),
    },
    {
        "title": "Challenge 9 (Bonus): Operator Precedence Surprises",
        "snippet": CHALLENGE_9_SNIPPET,
        "func": challenge_9,
        "explanation": (
            "Unary minus binds LOOSER than `**`, so `-2 ** 2` parses as `-(2 ** 2)` = -4, not "
            "(-2) ** 2 = 4. `*` binds tighter than `+`, so 2 + 3*4 = 14. Comparison operators bind "
            "tighter than `not`, so `not True == False` parses as `not (True == False)` = `not False` "
            "= True."
        ),
    },
]


def run_challenge(idx, challenge):
    print("=" * 70)
    print(f"{challenge['title']}")
    print("=" * 70)
    print("Read this snippet and predict the EXACT output before scrolling on:\n")
    print(challenge["snippet"])
    print("-- your prediction goes here --\n")

    _, captured = capture_stdout(challenge["func"])
    print("ACTUAL (verified by real execution):")
    print("-" * 40)
    print(captured.rstrip("\n"))
    print("-" * 40)
    print(f"WHY: {challenge['explanation']}\n")


def main():
    print("MODULE 14 - CODE TRACING CHALLENGES (Self-Verifying Answer Key)")
    print(f"This script contains {len(CHALLENGES)} code-tracing challenges.\n")

    assert len(CHALLENGES) >= 8, "Expected at least 8 code-tracing challenges"

    for i, challenge in enumerate(CHALLENGES, 1):
        run_challenge(i, challenge)

    print("=" * 70)
    print(f"All {len(CHALLENGES)} challenges executed successfully; outputs above were captured "
          "from REAL code execution, not hand-typed, so they are guaranteed correct.")


if __name__ == "__main__":
    main()
