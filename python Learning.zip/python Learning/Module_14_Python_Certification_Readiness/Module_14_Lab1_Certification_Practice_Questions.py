"""
Module 14 - Python Certification Readiness
Lab 1: Certification Practice Questions

A self-contained, non-interactive certification-style practice test.
Each question is modeled as data (question / options / answer_index / explanation
/ topic), covering the 8 recap topics from Module 14. Running this script prints
every question, its options, a short pause marker, and then reveals the correct
answer letter + explanation — simulating an "answer key review" mode with no
blocking input() calls.

Run with:  python3 Module_14_Lab1_Certification_Practice_Questions.py
"""

TOPICS = [
    "Exam Strategy & Question Types",
    "Core Syntax & Data Types",
    "Control Flow",
    "Functions",
    "Data Structures",
    "OOP",
    "Exceptions & Modules",
    "Advanced Recap (Decorators/Generators/Testing/PEP 8)",
]

QUESTIONS = [
    {
        "topic": "Exam Strategy & Question Types",
        "question": "A certification question shows a code snippet and four possible printed outputs. "
                    "What is the single most reliable way to answer it?",
        "options": [
            "A. Guess based on which option 'looks right'",
            "B. Trace the code line-by-line, tracking each variable's value",
            "C. Pick the longest option, since exams favor detailed answers",
            "D. Skip it and come back only if time allows, without reading it first",
        ],
        "answer_index": 1,
        "explanation": "Predict-the-output questions are won by disciplined manual tracing of variable "
                       "state line-by-line, not by pattern-matching the answer's appearance.",
    },
    {
        "topic": "Exam Strategy & Question Types",
        "question": "Which strategy best describes 'process of elimination' on a 4-option multiple choice question?",
        "options": [
            "A. Eliminate options that are definitely wrong (wrong type/error) before choosing among the rest",
            "B. Always choose option C because it statistically appears most often",
            "C. Never change your first answer once chosen",
            "D. Only read option A and D, skipping B and C to save time",
        ],
        "answer_index": 0,
        "explanation": "Elimination means ruling out clearly incorrect options first so you choose from a "
                       "smaller, more considered set rather than guessing from all four blindly.",
    },
    {
        "topic": "Core Syntax & Data Types",
        "question": "What does `print(True + True + False)` output?",
        "options": ["A. TypeError", "B. 2", "C. TrueTrueFalse", "D. 1.0"],
        "answer_index": 1,
        "explanation": "bool is a subclass of int; True behaves as 1 and False as 0 in arithmetic, so "
                       "1 + 1 + 0 == 2.",
    },
    {
        "topic": "Core Syntax & Data Types",
        "question": "What is the result of `int('3.5')`?",
        "options": [
            "A. 3",
            "B. 4",
            "C. Raises ValueError",
            "D. 3.5",
        ],
        "answer_index": 2,
        "explanation": "int() cannot parse a string containing a decimal point directly; it raises "
                       "ValueError. You would need float('3.5') then int(...) to truncate it.",
    },
    {
        "topic": "Core Syntax & Data Types",
        "question": "What does `print(7 / 2, 7 // 2)` output?",
        "options": ["A. 3 3", "B. 3.5 3", "C. 3.5 3.5", "D. 4 3"],
        "answer_index": 1,
        "explanation": "`/` is true division and always returns a float (3.5); `//` is floor division "
                       "and returns 3 for positive operands.",
    },
    {
        "topic": "Control Flow",
        "question": "What does the following print?\n"
                    "    for i in range(3):\n"
                    "        if i == 1:\n"
                    "            continue\n"
                    "        print(i)",
        "options": ["A. 0 1 2", "B. 0 2", "C. 1", "D. 0 1"],
        "answer_index": 1,
        "explanation": "`continue` skips the print only for i == 1, so 0 and 2 are printed; the loop "
                       "still completes all three iterations.",
    },
    {
        "topic": "Control Flow",
        "question": "A for-loop has no `break` statement anywhere in its body. What happens to its `else` clause?",
        "options": [
            "A. It never runs because there is no break to trigger it",
            "B. It always runs after the loop finishes, since break never fired",
            "C. It raises a SyntaxError because else requires a break",
            "D. It only runs if the loop iterable was empty",
        ],
        "answer_index": 1,
        "explanation": "A loop's `else` clause runs whenever the loop completes WITHOUT hitting `break`. "
                       "With no break in the body at all, it always executes after normal completion.",
    },
    {
        "topic": "Functions",
        "question": "What happens on the SECOND call to `f()` below?\n"
                    "    def f(x=[]):\n"
                    "        x.append(1)\n"
                    "        return x\n"
                    "    f()\n"
                    "    print(f())",
        "options": ["A. [1]", "B. [1, 1]", "C. []", "D. TypeError"],
        "answer_index": 1,
        "explanation": "The default list is created once at def-time and shared across calls, so the "
                       "second call appends to the list already holding [1] from the first call.",
    },
    {
        "topic": "Functions",
        "question": "What does this print?\n"
                    "    x = 5\n"
                    "    def f():\n"
                    "        print(x)\n"
                    "        x = 10\n"
                    "    f()",
        "options": ["A. 5", "B. 10", "C. UnboundLocalError", "D. NameError"],
        "answer_index": 2,
        "explanation": "Because x is assigned inside f, Python treats x as local for the whole function "
                       "body, so print(x) reads the not-yet-assigned local variable -> UnboundLocalError.",
    },
    {
        "topic": "Functions",
        "question": "Given `def f(*args, **kwargs): print(args, kwargs)`, what does `f(1, 2, a=3)` print?",
        "options": [
            "A. (1, 2) {'a': 3}",
            "B. [1, 2] {'a': 3}",
            "C. (1, 2, 3) {}",
            "D. TypeError: too many arguments",
        ],
        "answer_index": 0,
        "explanation": "*args collects extra positional arguments into a tuple (1, 2); **kwargs collects "
                       "extra keyword arguments into a dict {'a': 3}.",
    },
    {
        "topic": "Data Structures",
        "question": "`a = [[1, 2], [3, 4]]`; `b = list(a)`; `b[0].append(9)`. What is `a[0]` now?",
        "options": ["A. [1, 2]", "B. [1, 2, 9]", "C. [1, 2, 9, 9]", "D. TypeError"],
        "answer_index": 1,
        "explanation": "list(a) is a shallow copy — the outer list is new, but nested lists are shared "
                       "references, so mutating b[0] also mutates a[0].",
    },
    {
        "topic": "Data Structures",
        "question": "What does `[1, 2, 3, 4, 5][10:20]` evaluate to?",
        "options": ["A. IndexError", "B. []", "C. None", "D. [1, 2, 3, 4, 5]"],
        "answer_index": 1,
        "explanation": "Slicing clamps out-of-range bounds silently and never raises IndexError; a "
                       "fully out-of-range slice simply returns an empty list.",
    },
    {
        "topic": "Data Structures",
        "question": "Which of the following can be used as a dictionary key?",
        "options": ["A. A list", "B. A dict", "C. A tuple of ints", "D. A set"],
        "answer_index": 2,
        "explanation": "Dict keys must be hashable; lists, dicts, and sets are mutable and unhashable, "
                       "but a tuple of immutable elements (like ints) is hashable.",
    },
    {
        "topic": "OOP",
        "question": "A class defines only `__repr__`, not `__str__`. What does `print(obj)` use?",
        "options": [
            "A. The default object.__str__, ignoring __repr__",
            "B. __repr__, since Python falls back to it when __str__ is absent",
            "C. Raises an AttributeError",
            "D. An empty string",
        ],
        "answer_index": 1,
        "explanation": "print()/str() prefer __str__ but fall back to __repr__ when __str__ isn't "
                       "defined on the class.",
    },
    {
        "topic": "OOP",
        "question": "In `class Dog(Animal):`, what is the purpose of calling `super().__init__(...)` inside Dog's `__init__`?",
        "options": [
            "A. It deletes the parent class",
            "B. It calls the parent class's initializer so Animal's setup still runs",
            "C. It is required syntax with no functional effect",
            "D. It converts Dog into a standalone class with no parent",
        ],
        "answer_index": 1,
        "explanation": "super().__init__(...) invokes the parent class's initializer, ensuring "
                       "attributes/setup defined in Animal.__init__ still get applied to the Dog instance.",
    },
    {
        "topic": "Exceptions & Modules",
        "question": "Which exception class is the direct parent of `ZeroDivisionError`?",
        "options": ["A. Exception", "B. LookupError", "C. ArithmeticError", "D. ValueError"],
        "answer_index": 2,
        "explanation": "ZeroDivisionError derives from ArithmeticError, which in turn derives from "
                       "Exception.",
    },
    {
        "topic": "Exceptions & Modules",
        "question": "`except Exception:` is used as a catch-all in some code. Which exception will it NOT catch?",
        "options": ["A. ValueError", "B. KeyError", "C. SystemExit", "D. ZeroDivisionError"],
        "answer_index": 2,
        "explanation": "SystemExit derives directly from BaseException, not Exception, so a bare "
                       "`except Exception` does not catch it (by design, so sys.exit() isn't silently swallowed).",
    },
    {
        "topic": "Advanced Recap (Decorators/Generators/Testing/PEP 8)",
        "question": "What happens when you call a generator function like `gen()` (which contains `yield`)?",
        "options": [
            "A. The entire function body executes immediately and returns its final value",
            "B. A generator object is returned immediately; the body runs only as it is iterated",
            "C. It raises a SyntaxError because yield requires a loop",
            "D. It behaves exactly like a normal return-based function",
        ],
        "answer_index": 1,
        "explanation": "Calling a generator function does not run its body; it returns a generator "
                       "object, and code runs incrementally each time next() is called, pausing at yield.",
    },
    {
        "topic": "Advanced Recap (Decorators/Generators/Testing/PEP 8)",
        "question": "Per PEP 8, what is the conventional naming style for a function or variable?",
        "options": ["A. camelCase", "B. PascalCase", "C. snake_case", "D. kebab-case"],
        "answer_index": 2,
        "explanation": "PEP 8 recommends snake_case for functions and variables, PascalCase for "
                       "classes, and UPPER_CASE for constants.",
    },
]


def _letter(index):
    return chr(ord("A") + index)


def run_review_mode():
    """Non-interactive 'answer key review' pass: print question, options,
    a pause marker, then the correct answer + explanation."""
    print("=" * 70)
    print("MODULE 14 - CERTIFICATION PRACTICE TEST (Answer Key Review Mode)")
    print("=" * 70)

    for i, q in enumerate(QUESTIONS, 1):
        print(f"\nQuestion {i}  [Topic: {q['topic']}]")
        print("-" * 70)
        print(q["question"])
        for opt in q["options"]:
            print(f"   {opt}")
        print("   ... (reviewing answer) ...")
        correct_letter = _letter(q["answer_index"])
        print(f"   >> Correct answer: {correct_letter}")
        print(f"   >> Why: {q['explanation']}")

    print("\n" + "=" * 70)


def summarize():
    """Prove the practice-question data set is complete and consistent."""
    total = len(QUESTIONS)
    topics_covered = sorted(set(q["topic"] for q in QUESTIONS))
    topic_counts = {}
    for q in QUESTIONS:
        topic_counts[q["topic"]] = topic_counts.get(q["topic"], 0) + 1

    print("SCORE SUMMARY / DATA-INTEGRITY CHECK")
    print("-" * 70)
    print(f"This script contains {total} practice questions across {len(topics_covered)} topics.")
    print("Questions per topic:")
    for t in TOPICS:
        print(f"   - {t}: {topic_counts.get(t, 0)}")

    # Consistency assertions: every question must be well-formed.
    assert total >= 15, f"Expected at least 15 questions, found {total}"
    assert set(topics_covered) == set(TOPICS), "Question topics do not match the declared 8-topic set"
    assert len(topic_counts) == 8, f"Expected questions spanning all 8 topics, found {len(topic_counts)}"
    for q in QUESTIONS:
        assert len(q["options"]) == 4, f"Question must have exactly 4 options: {q['question'][:40]!r}"
        assert 0 <= q["answer_index"] <= 3, "answer_index must be between 0 and 3"
        assert q["explanation"], "Every question must have a non-empty explanation"

    print("\nAll consistency checks passed:")
    print(f"   - >= 15 questions: OK ({total})")
    print("   - All 8 topics represented: OK")
    print("   - Every question has exactly 4 options: OK")
    print("   - Every answer_index is valid (0-3): OK")
    print("   - Every question has a non-empty explanation: OK")


def main():
    run_review_mode()
    print()
    summarize()


if __name__ == "__main__":
    main()
